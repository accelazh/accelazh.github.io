这是长篇“分布式存储架构和设计空间”的第四篇。原文很长，受微信公众号长度限制，需要分P发出。全文将依次总结各存储组件的技术和设计空间，本章关注一致性。

## 一致性（Consistency)

一致性是贯穿分布式存储系统设计的核心之一，技术种类繁多，涉及大多数组件。 我选择 __规模（scale）__ 作为一级分类来说明一致性的设计空间：从单节点级别、数据中心级别、到地理区域级别。 一般来说，要考虑的关键设计空间维度如下。 有关更多信息，请参见 [_分布式事务 TODO_](.)[294]。

   * __同步点（Point of sync）__。 当一条数据被更改时，必须有一个时间点，在该时间点之后更改对用户可见，称之为同步点。 它必须是原子的，即在不可见与可见之间没有半状态（half states）。 它必须信守承诺，即一旦跨过同步点，就无法反悔。 它必须达成共识（consensus），即系统中的组件在同步点上达成一致，根据其传播分为强一致性（strong consistency）和最终一致性（eventual consistency）。 对于实现，同步点通常依赖于 [_原子磁盘扇区写入_](.)[299]（atomic disk sector write，例如日志提交），[_原子内存指针切换_](.)[300]（atomic memory pointer switch，例如 B+-树），或由另一个（另一组）节点作为一致性核心（Consistent Core，例如领导者节点）。

   * __确保顺序（Ensure ordering）__。 系统必须就先发生或后发生的事情达成一致。 这对于 Append-only 或基于 WAL 的系统来说是自然的，类似的是每个操作都可以通过上锁的数据结构来序列化（serialize）的系统。 当系统涉及多个节点，或者日志有多个并行段（parallel segment）时，确保顺序会变得棘手。 版本控制（versioning 或时间戳 timestamp）被引入，其中全序（Total Ordering）对应可序列化（Serializable），偏序（Partial Ordering）对应 Vector Clock，不相交（disjoint）的读/写版本时间戳对应快照隔离（Snapshot Isolation，可序列化事务级别需要相同的读写时间戳）。 事务系统决定的时间戳顺序可能与现实世界不同，这个问题对应外部一致性（External Consistency）。 处理排序冲突的方法各不相同，“新来者等待”对应普通的上锁（locking）或悲观并发控制（Pessimistic Concurrency Control），“新来者重试”对应 OCC （Optimistic Concurrent Control，乐观并发控制），“抢占锁”（preempting a lock）对应抢占式并发控制（preemptive concurrency control）或 [_wound-wait_](.)[301]。 并发机制的实现上，通常 CPU/内存级别使用 locks/latches，磁盘级别使用 flush 或者 direct write。

   * __分别讨论 ACID__。 在事务 ACID 中，通常 ACI 和一致性是统一的，但是 D 持久性（durability）有可能是分开的。 大多数存储系统选择一起实现它们，主要是因为磁盘上的排序（ordering）是通过 flush 或 direct write 实现的，它们与持久性耦合。 我们可以在下文中看到更多打破这一模式并提高性能的技术（例如 Soft Update、Journal Checksum）。

### 单节点级别的一致性（Single node level consistency）

在 __CPU/内存的级别__ 上，基础是单个 CPU 内核确保顺序一致性（尽管编译器和 CPU 重新排序指令）。 多核编程涉及指令原子性（例如 Intel x64 arch 保证 [_64 位读/写是原子的_](.)[300]）、内存操作排序（例如 load/store 语义）、内存更改的可见性（visibility，例如 volatile 关键字、缓存失效 cache invalidation）; 它们可以在 [_C++ 内存模型_](.)[302] 下进行总结。 CPU 提供细粒度的指令，例如上锁/CAS（例如 lock、xchg、cmpxchg）、内存屏障（memory fencing，例如 lfence、sfence、mfence）、缓存 flush（例如 CLFLUSH、CLWB）。 进一步，它们用于构建 [_编程中的锁_](.)[303]、[_无锁算法_](.)[70] 和 [_PMEM 提交协议_](.)[260]（如 O_DIRECT 刷到磁盘，CLFLUSH 刷缓存到内存/PMEM）。 更多技术可见于数据库中的 [_B+ 树上锁技术_](.)[304] 和 [_Linux 内核同步_](.)[305]。 它们不是本文架构设计的主要主题。

谈到存储，更多的关注给了 __内存/磁盘级别__ 和 __崩溃恢复__ （crash recovery，即系统完整性 system integrity）。 预写日志 (WAL) 是一致性（以及 ACID 中的写入原子性和持久性）的主流解决方案，随着 Append-only 存储系统（例如 LSM-tree）的采用趋势，它变得更加广泛。 WAL（redo/undo log）也是实现 [_数据库事务_](.)[306] 的必要组件，但是有更多的方法来保持一致性。

   * __Write-ahead logging__ （预写日志，WAL），一致性由顺序记录的日志和提交条目（commit entry）来保证。 元数据/数据更改通过 journaling/logging 持久保存到磁盘； 其中 journaling/logging 的提交条目是更改提交可见的同步点，它们同步 flush 到磁盘。 日志是自然的完全有序的，也不排除使用版本控制/时间戳。 数据库进一步使用 redo 日志和 undo 日志（[_ARIES_](.)[306]），其中 redo 日志是通常意义的日志，而 undo 日志为支持 “No Force, Steal” 引入，即一个页面（page）可以提前 flush 到磁盘，即使所属的（大）事务尚未提交。

   * __Shadow Paging__，由 COW （Copy-on-write，写时复制）和原子指针切换实现一致性，示例是 BtrFS。 更新通过 COW 添加到新 B+ 树页面（pages）。 提交时，同步点在于原子地切换父节点的指针到新页面。 同样的模式在内存和磁盘中都使用，其中 CPU/内存通过锁控制排序。 该技术有利于内置（built-in）对快照的支持，通过 COW 提高并行性（parallelism），并且没有序列化日志提交时的瓶颈。 然而，叶节点的变化会导致父节点的变化，并向上传播到树根，这是昂贵的（除非使用页面映射表，Page Mapping Table）。

   * __Soft Update__，一致性通过跟踪内存中的排序实现，但并不确保持久性，例子是 [_FFS_](.)[307]。 Inode 跟踪更新的依赖关系，系统确保（enforce）它们的执行顺序。 实际写入磁盘可以延后，异步发生，并提高并行性。 用户需要等待更新被持久化后的通知。 Soft Update 本身并不能保证必要的元数据/数据更改在崩溃（crash）时是持久的（durable），需要谨慎地实现，以确保崩溃一致性（Crash Consistency）。

   * __Transactional Checksumming__，一致性通过跟踪磁盘上的排序，但并不确保持久性。 系统开始并行写入块 A/B，但期望块 A 仅在块 B 之后提交。 块 A 携带 B 的校验码（checksum）； 如果在中间发生崩溃，在磁盘上留下 A 而没有 B ，校验码可以告诉块 A 无效。 该技术打破了顺序记录日志的瓶颈，但是在故障恢复期间需要付出更多代价以确定同步点。 有关更多信息，请参见 [_乐观崩溃一致性_](.)[308]（Optimistic Crash Consistency）。

__元数据/数据组件__ 之间的一致性也需要维护（接[元数据章节 TODO](.)）。 典型的存储系统将新更改的可见性从磁盘数据传播到索引，然后传播到用户。 这里的索引是一种元数据，它指示如何查找数据，例如 inode 树。 从系统内部，传播通常是 __最终一致性__ （eventual consistency）的，例如分配磁盘空间，写入数据，然后过一段时间提交日志。 通过接口（隐藏系统内部结构）和通知（异步），这些操作对用户变成“原子的”。 当元数据和数据被分离到不同的节点组时，同样的设计模式适用。

### 数据中心级别的一致性（Datacenter level consistency）

在单节点级别的一致性之后，我们来到分布式多节点级别。 从强到弱，现代分布式数据库通常在可序列化（Serializable）或快照隔离（Snapshot Isolation）级别实现事务 ACID 。 存储系统通常为数据复制（Data Replication）提供强一致性，NoSQL、缓存、跨系统交互通常采用较弱的一致性模型，来降低复杂性和性能开销。

   * __分布式事务__ （Distributed Transaction）。 有关更多信息，请参阅 [_分布式事务 TODO_](.)[294] 文章。 例子有 Spanner、Percolator、CockroachDB、TiDB。 这些实现在同步点、如何确保（enforce）排序（ordering）和锁冲突处理方面有所不同。 此外，数据库的全局二级索引，为了与用户写维持强一致性，也实现了分布式事务。

![分布式事务策略](/images/arch-design-dist-transaction.png "分布式事务策略")  TODO

   * __Raft 数据复制__。 例子有 CockroachDB、TiDB。 就像在 Paxos quorum 中运行元数据一样，数据分区（data partition）通过 Raft 协议（一种 Paxos 变体 variant）进行复制。 这确保了强一致性，并重用了 Paxos 上的优化，例如 [_乱序提交_](.)[309] （Out-of-order Commit）。 [_Megastore_](.)[310] 中有 Paxos 复制的更全面的优化。

   * __3-way Replication__。 例子有 Ceph，以及类似的 Azure 存储中使用的 [_Chain Replication_](.)[311]。 它比 Raft 更简单，也更早出现。 经典的实现是通过 Consistent Core（例如元数据集群）选出一个 Leader 节点来驱动具有强一致性的 Follower 节点。 可以通过流水线（Pipelining）优化吞吐量。

   * __Quorum Read/Write__。 例子有 Dynamo、Cassandra。 总共有 N 个副本，在 > N/2 个副本上进行读取或写入操作，来保证与最新版本的副本（replica）相交。 该实现也增加了更多复杂性，例如处理读放大（或简单地返回缓存的版本）、版本跟踪、以及节点写入失败。

   * __日志即数据库__（Log is Database）。 与 WAL 简化单节点一的致性类似，分布式系统可以构建在共享日志（Shared Logging）服务之上，例如 FoundationDB、Helios Indexing。 这个想法可以扩展到在提供强一致性并充当单个节点的任何共享存储服务之上构建系统，例如 一个分布式文件系统，一个页面存储（Page Store）。 示例包括 AWS Aurora Multi-master、Azure 存储。 这个想法还扩展到以同步或最终一致的方式传播更改，这自然适用于数据库 WAL。 例如 Helios Indexing、[_MySQL BinLog Replication_](.)[312]。

以上技术建立了强一致性，对于较弱的一致性：

   * __最终一致性__ （Eventual Consistency）。 通常，如果系统不对一致性做任何事情，并让更新传播，那就是最终一致性。 更好的实现提供版本控制来测量传播，并保证完全传播的最终时间。

   * __因果一致性__ （Causal Consistency）。 与 [元数据章节 TODO ](.) 相同。 它与最终一致性兼容，客户端必须看到它已经看到的东西。 对于实现，客户端维护它希望服务器返回的低水位版本号（low watermark）。

   * __定制的一致性级别__。 例子是 RAMP-TAO，它检查本地结果集是否满足“读取原子性”（Read Atomicity），并从 RefillLibrary 中获取缺失的版本。 通常，可以通过使用数据跟踪版本、即时（on the fly）检查一致性约束、以及缓存查询结果，来实现更多定制的一致性级别。

   * __补偿事务__ （Compensation Transaction）。 请参阅这篇 [_补偿事务_](.)[313] 文章。 它联合多个系统来构建（pseudo）ACID 事务。 每个系统内部都支持 ACID 事务和幂等（idempotent）操作。 客户端驱动事务，以单向最终一致性方式在多个系统中传播更新，支持至少一次（At Least Once）语义和明确的完成时间。 如果一个系统在过程中失败，破坏了原子性，客户端通过在每个系统上以相反的顺序重放“补偿事务”来回滚。 隐藏所有的复杂性，它为客户端提供了一个看似 ACID 的事务接口。 该技术常用于构建大型互联网公司的预订服务（booking service）。 此外，可以添加一个“预留”（reservation）步骤来使系统不易出错，这使它更像 2PC（除了其他客户端可以读取中间状态）。

### 地理区域级别的一致性（Geo-regional level consistency）

当涉及到跨区域多数据中心级别时，一致性的技术与单数据中心级别类似。 但由于延迟开销，更大的规模使得强一致性或同步复制变得困难。 大多数实现是最终一致性的，灾备恢复领域定义了度量概念：

   * __RTO__（Recovery Time Object，恢复时间目标）。 在第一个区域发生灾难后，系统和应用程序需要多长时间在第二个区域恢复。 如果系统启动、缓存预热、DNS 切换需要时间，RTO 可能会很长。

   * __RPO__（Recovery Point Object，恢复点目标）。 因为跨地域复制是异步的，所以从复制的数据到最新的数据是有延迟的，RPO 定义延迟窗口。 它反映在第二个区域中恢复后将丢失多少最近的数据。

除了与单数据中心级别的一致性重复的那些之外，常用技术如下。 相比之下，更多的优化针对不稳定的链路和 WAN（Wide-area network，广域网）中的低带宽。

   * __地理复制__（Geo-replication）。 数据库通常支持用于跨区域备份的异步复制（最终一致性），通常通过复制日志，例如 MySQL BinLog 复制，和 [_Redis replication_](.)[314] 主从指令流（command stream）。 异步地理复制不排除同步复制一小块关键元数据，也不排除客户端查询主区域（primary region）以确定最新版本。

   * __增量差异__（Incremental Diff）。 Ceph 提供 [_RBD diff_](.)[315] 导出快照增量，可用于以半自动方式进行地理复制。

   * __日志即数据库__。 上面已经总结了大部分。 使用日志以最终一致性的方式复制更新，例如 Helios Indexing、MySQL BinLog Replication。

以上是最终一致性复制。 对于强一致性的地理复制，通常采用（并优化）Paxos 复制，而序列化事务的时钟同步成为一个更大的问题。

   * __Megastore Paxos__。 [_Google Megastore_](.)[310] 使用优化的 Paxos 协议跨 WAN 同步复制。 与主/从复制相比，附近或利用率较低的数据中心的任何 Paxos 副本都可以领导事务来平衡负载。 写入只需 > N/2 个副本的 Ack，这减少了跨数据中心的延迟。 通过使用协调者（coordinator）跟踪哪个副本具有最新版本，本地数据中心优先使用本地读取。 写入使用 [_Leader Paxos_](.)[297]，其中倾向选择附近副本作为领导者。 当参与者（participant）太少时，引入见证者副本（Witness Replica）来组成 Quorum；见证者副本参与投票和复制日志，但不会执行日志来服务数据库数据。 引入了只读副本，它不投票，但重播（replay）日志以服务数据库数据，提供快照读取。 基于实现，Paxos 跨数据中心本质上是复制日志，类似 “日志即数据库”。

   * __Spanner & TrueTime__。 与 Megastore 一样，[_Google Spanner_](.)[316] 将副本存储在不同的地理区域，并采用 Paxos 复制。 分布式事务由 2PC 实现，其 Liveness 由参与者的 Paxos 副本的高可靠性保证。 特殊部分是 [_TrueTime_](.)[317]，其用于跨数据中心同步时钟，从而通过 Commit Wait 实现外部一致性（[_Distributed Transactions_](.)[294]）。 TrueTime 依赖于定制硬件，即 GPS 接收器和原子钟，作为每个数据中心的主时间主节点，保证 [_全球时钟漂移小于7毫秒_](.)[122]。

   * __CockroachDB & Hybrid-Logical Clock (HLC)__。 与 Spanner 一样，[_CockroachDB_](.)[318] 采用 Paxos (Raft) 跨区域数据复制，以及 2PC 进行分布式事务。 读取优先选择附近的副本，而写入可以首先选择同一区域中的附近副本，并异步复制到其它副本。 与 Spanner TrueTime 不同，CockroachDB 使用 [_HLC_](.)[121] 作为跨数据中心的时钟。 HLC 在其逻辑组件（logical component）上提供因果关系跟踪，并在其物理组件（physical component）上提供单调递增的 Epoch，并使用 NTP 作为纯软件时钟同步协议。

## 引用

// TODO insert P0

(封面图片 by SBA73, CC BY-SA 2.0: https://99percentinvisible.org/episode/la-sagrada-familia/. 注：本文为个人观点总结，作者工作于微软)
