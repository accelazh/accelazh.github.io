我将开始长篇“分布式存储架构和设计空间”，原文有5W多字词。微信公众号限制长度，需要分P发出。第零篇是文章的引用列表（真正的程序员从零开始数）。

# 引用

[1] 忠实地反射世界 : https://www.zhihu.com/question/346067016

[2] COGS : https://en.wikipedia.org/wiki/Cost_of_goods_sold

[3] GXSC's answer : https://www.zhihu.com/question/24614033/answer/497338972

[4] Score matrix : https://www.productplan.com/learn/prioritization-matrix-example/

[5] Ele.me Payment System : https://mp.weixin.qq.com/s/mtPQLSONUCWOC2HDPRwXNQ

[6] Simple is beauty, Architecture 3 principles : https://xie.infoq.cn/article/5e899856e29017c1079b3be86

[7] MVP : https://en.wikipedia.org/wiki/Minimum_viable_product

[8] Chrome Apps : https://developer.chrome.com/docs/apps/first_app/

[9] Minecraft : http://gametyrant.com/news/5-best-modding-tools-for-minecraft

[10] Opensource Envoy : https://mattklein123.dev/2021/09/14/5-years-envoy-oss/

[11] 道延架构 : https://mp.weixin.qq.com/s?__biz=Mzg5Mjc3MjIyMA==&mid=2247544273&idx=1&sn=d7b9cec80cd593d28b42f5b6179af8be

[12] KISS : https://en.wikipedia.org/wiki/KISS_principle

[13] Conway's Law : https://en.wikipedia.org/wiki/Conway%27s_law

[14] D Score : https://book.douban.com/subject/26915970/

[15] Measuring software complexity : https://thevaluable.dev/complexity-metrics-software/

[16] Domain-drive Design - Chapter 1 : https://mp.weixin.qq.com/s?__biz=MzA4NTkwODkyMQ==&mid=2651257296&idx=1&sn=7273271d15bc7e2e41da58a155c6e4ab&chksm=84229506b3551c10f20437b06e0e2fb75c1cb0642d5571ea0b30f534a9000b7bb4f2946a393c

[17] 4+1 View : https://zhuanlan.zhihu.com/p/112531852

[18] Design Patterns : https://en.wikipedia.org/wiki/Software_design_pattern#Creational_patterns

[19] Coding Styles : https://google.github.io/styleguide/cppguide.html

[20] Code Refactoring : https://m.douban.com/book/subject/1229923/

[21] Code Complete : https://book.douban.com/subject/1477390/

[22] UML diagrams : https://en.wikipedia.org/wiki/Unified_Modeling_Language

[23] PSP : https://www.geeksforgeeks.org/personal-software-process-psp/

[24] Combining CMMI/PSP : https://www.isixsigma.com/tools-templates/combining-cmmia-psp-tsp-and-six-sigma-software/

[25] CMMI : https://en.wikipedia.org/wiki/Capability_Maturity_Model_Integration

[26] Domain-Driven Design : https://www.amazon.com/Domain-Driven-Design-Tackling-Complexity-Software/dp/0321125215

[27] IDDD flu vaccine : https://learning.oreilly.com/library/view/implementing-domain-driven-design/9780133039900/ch01lev2sec5.html#ch01lev2sec5

[28] Drive DDD design by language : https://learning.oreilly.com/library/view/implementing-domain-driven-design/9780133039900/ch02lev1sec4.html#ch02lev1sec4

[29] Core domains : https://cloud.tencent.com/developer/article/1709312

[30] Enterprise architecture : https://dev.to/dhruvesh_patel/software-architecture-five-common-design-principles-2il0

[31] 四横三纵 architecture : https://mp.weixin.qq.com/s?__biz=MzI4OTc4MzI5OA==&mid=2247544948&idx=6&sn=e89031d33a1b7f753095164b022ae80d

[32] Alibaba 四横三纵 : https://posts.careerengine.us/p/5f0db6acb5fef84f7de7203d

[33] Kenneth Lee's blogs : https://gitee.com/Kenneth-Lee-2012/MySummary/tree/master/%E8%BD%AF%E4%BB%B6%E6%9E%84%E6%9E%B6%E8%AE%BE%E8%AE%A1

[34] Kenneth Lee's articles : https://www.zhihu.com/column/kls-software-arch-world

[35] On Designing and Deploying Internet-Scale Services : https://www.usenix.org/legacy/event/lisa07/tech/full_papers/hamilton/hamilton_html/

[36] EBay's 三高 design P1 : https://mp.weixin.qq.com/s/bnhXGD7UhwTxL8fpddzAuw

[37] EBay's 三高 design P2 : https://mp.weixin.qq.com/s/Xyvfx9mLKqquulnrhFi42Q

[38] AWS's 如何软件开发 : https://mp.weixin.qq.com/s?__biz=MzI4OTc4MzI5OA==&mid=2247520243&idx=1&sn=dfce28433ff14ef188055dc5daf67bd7

[39] SDN : https://en.wikipedia.org/wiki/Software-defined_networking

[40] Netflix microservice architecture : https://medium.com/swlh/a-design-analysis-of-cloud-based-microservices-architecture-at-netflix-98836b2da45f

[41] Kappa architecture : https://towardsdatascience.com/a-brief-introduction-to-two-data-processing-architectures-lambda-and-kappa-for-big-data-4f35c28005bb

[42] Online, nearline, offline : https://netflixtechblog.com/system-architectures-for-personalization-and-recommendation-e081aa94b5d8

[43] Snowflake : https://www.usenix.org/conference/nsdi20/presentation/vuppalapati

[44] Snowflake architecture : https://medium.com/codex/why-snowflake-data-cloud-over-lakehouse-architecture-647b27ecf59e

[45] DDD onion architecture : https://herbertograca.com/2017/11/16/explicit-architecture-01-ddd-hexagonal-onion-clean-cqrs-how-i-put-it-all-together/

[46] React-Redux : https://medium.com/mofed/react-redux-architecture-overview-7b3e52004b6e

[47] Growth mindset : https://www.youtube.com/watch?v=M1CHPnZfFmU

[48] CoolShell design principles : https://coolshell.cn/articles/4535.html

[49] Spring DOI : https://www.baeldung.com/spring-dependency-injection

[50] AspectJ AOP : https://docs.spring.io/spring-framework/docs/4.3.15.RELEASE/spring-framework-reference/html/aop.html

[51] Microsoft SDP : https://azure.microsoft.com/en-us/blog/advancing-safe-deployment-practices/

[52] CAP : https://www.educative.io/blog/what-is-cap-theorem

[53] Patterns of Distributed Systems : https://martinfowler.com/articles/patterns-of-distributed-systems/

[54] Consistent Core : https://martinfowler.com/articles/patterns-of-distributed-systems/consistent-core.html

[55] Replicated Log : https://martinfowler.com/articles/patterns-of-distributed-systems/replicated-log.html

[56] Cloud Design Patterns : https://docs.microsoft.com/en-us/azure/architecture/patterns/

[57] Designing Data-Intensive Applications : https://www.oreilly.com/library/view/designing-data-intensive-applications/9781491903063/

[58] CMU 15-721 : https://15721.courses.cs.cmu.edu/spring2020/schedule.html

[59] On Designing and Deploying Internet-Scale Services : https://www.usenix.org/legacy/event/lisa07/tech/full_papers/hamilton/hamilton_html/index.html

[60] SteveY's comments : https://coolshell.cn/articles/5701.html

[61] TiDB : https://www.vldb.org/pvldb/vol13/p3072-huang.pdf

[62] Greenplum : https://arxiv.org/pdf/2103.11080.pdf

[63] LSM-based Storage Techniques: A Survey : https://arxiv.org/abs/1812.07527

[64] Zhihu : https://zhuanlan.zhihu.com/p/351241814

[65] Scaling Replicated State Machines with Compartmentalization : https://arxiv.org/abs/2012.15762

[66] An Empirical Evaluation of In-Memory Multi-Version Concurrency Control : http://www.vldb.org/pvldb/vol10/p781-Wu.pdf

[67] In-Memory Big Data Management and Processing : https://www.comp.nus.edu.sg/~ooibc/TKDE-2015-inmemory.pdf

[68] Constructing and Analyzing the LSM Compaction Design Space : http://vldb.org/pvldb/vol14/p2216-sarkar.pdf

[69] Dostoevsky: Better Space-Time Trade-Offs for LSM-Tree : https://www.youtube.com/watch?v=fmXgXripmh0

[70] Latch-free Synchronization in Database Systems, RCU, Lock-free algorithms : http://www.jmfaleiro.com/pubs/latch-free-cidr2017.pdf

[71] Optimal Column Layout for Hybrid Workloads, Optimal Column Layout : https://stratos.seas.harvard.edu/files/stratos/files/caspervldb2020.pdf

[72] Access Path Selection in Main-Memory Optimized Data Systems, Access Path Selection : https://www.eecs.harvard.edu/~kester/files/accesspathselection.pdf

[73] Redis : https://redis.io/

[74] Tendis : https://cloud.tencent.com/developer/article/1815554

[75] Kangaroo cache : https://www.pdl.cmu.edu/PDL-FTP/NVM/McAllister-SOSP21.pdf

[76] Scaling Memcached, Mcrouter : https://www.usenix.org/conference/nsdi13/technical-sessions/presentation/nishtala

[77] CacheLib : https://www.usenix.org/conference/osdi20/presentation/berg

[78] RAMP-TAO cache consistency, Facebook TAO : https://www.vldb.org/pvldb/vol14/p3014-cheng.pdf

[79] BCache : https://bcache.evilpiepirate.org/BcacheGuide/

[80] Ceph : https://segmentfault.com/a/1190000038448569

[81] BtrFS : https://dominoweb.draco.res.ibm.com/reports/rj10501.pdf

[82] XFS : http://www.scs.stanford.edu/nyu/03sp/sched/sgixfs.pdf

[83] EXT4 : https://ext4.wiki.kernel.org/index.php/Ext4_Disk_Layout

[84] CephFS : https://docs.ceph.com/en/pacific/cephfs/index.html

[85] Dynamic subtree partitioning : https://ceph.io/assets/pdfs/weil-mds-sc04.pdf

[86] Mantle load balancing : https://engineering.ucsc.edu/sites/default/files/technical-reports/UCSC-SOE-15-10.pdf

[87] MDS journaling : https://docs.ceph.com/en/pacific/cephfs/mds-journaling/

[88] Locks : https://docs.ceph.com/en/pacific/cephfs/mdcache/#distributed-locks-in-an-mds-cluster

[89] HopsFS : https://www.usenix.org/conference/fast17/technical-sessions/presentation/niazi

[90] HDFS : https://storageconference.us/2010/Papers/MSST/Shvachko.pdf

[91] Google Filesystem : https://static.googleusercontent.com/media/research.google.com/en//archive/gfs-sosp2003.pdf

[92] Big Table : https://static.googleusercontent.com/media/research.google.com/en//archive/bigtable-osdi06.pdf

[93] Chubby : https://static.googleusercontent.com/media/research.google.com/en//archive/chubby-osdi06.pdf

[94] HBase : https://hbase.apache.org/

[95] Hive : https://hive.apache.org/

[96] Spark : https://databricks.com/blog/2014/01/21/spark-and-hadoop.html

[97] Hudi : https://hudi.apache.org/docs/comparison/

[98] Isilon : http://doc.isilon.com/onefs/hdfs/02-ifs-c-hdfs-conceptual-topics.htm

[99] Ceph : https://www.ssrc.ucsc.edu/pub/weil-osdi06.html

[100] Ubuntu Openstack storage survey : https://ubuntu.com/blog/openstack-storage

[101] BlueStore, Double-write problem : https://mp.weixin.qq.com/s/dT4mr5iKnQi9-NEvGhI7Pg

[102] Ceph 10 year lessons : https://www.pdl.cmu.edu/PDL-FTP/Storage/ceph-exp-sosp19.pdf

[103] Wisckey : https://www.usenix.org/system/files/conference/fast16/fast16-papers-lu.pdf

[104] Azure Storage : https://azure.microsoft.com/en-us/blog/sosp-paper-windows-azure-storage-a-highly-available-cloud-storage-service-with-strong-consistency/

[105] AWS S3 : https://stackoverflow.com/questions/564223/amazon-s3-architecture

[106] Nutanix : https://www.nutanix.com/hyperconverged-infrastructure

[107] Tectonic, Multitenancy : https://www.usenix.org/conference/fast21/presentation/pan

[108] Copyset Placement : http://www.stanford.edu/~skatti/pubs/usenix13-copysets.pdf

[109] TiDB : https://docs.pingcap.com/tidb/dev/tidb-architecture

[110] XtremIO : https://www.youtube.com/watch?v=lIIwbd5J7bE

[111] SolidFire : https://www.youtube.com/watch?v=AeaGCeJfNBg

[112] Pure Storage : https://www.purestorage.com/products.html

[113] Data Domain : https://www.usenix.org/legacy/events/fast08/tech/full_papers/zhu/zhu.pdf

[114] Rolling hash : https://www.gluster.org/deduplication-part-1-rabin-karp-for-variable-chunking/

[115] Ceph dedup : https://ceph.io/assets/pdfs/ICDCS_2018_mwoh.pdf

[116] Pelican : https://www.usenix.org/system/files/conference/osdi14/osdi14-paper-balakrishnan.pdf

[117] Flamingo : https://www.usenix.org/node/194437

[118] AWS Glacier : https://aws.amazon.com/s3/storage-classes/glacier/

[119] Pergamum : https://www.usenix.org/legacy/event/fast08/tech/full_papers/storer/storer_html/

[120] Tape Library : https://www.snia.org/sites/default/orig/DSI2015/presentations/ColdStorage/OasamuShimizu_Tape_storage_for_cold_data_archive.pdf

[121] CockroachDB, HLC : https://dl.acm.org/doi/pdf/10.1145/3318464.3386134

[122] Google Spanner, Less than 7 ms clock drifts globally : https://static.googleusercontent.com/media/research.google.com/en//archive/spanner-osdi2012.pdf

[123] Hybrid-Logical Clock : https://www.cockroachlabs.com/docs/stable/architecture/transaction-layer.html

[124] Stores in RocksDB, CockroachDB on RocksDB : https://www.cockroachlabs.com/blog/cockroachdb-on-rocksd/

[125] Raft : https://www.cockroachlabs.com/docs/stable/architecture/replication-layer.html#raft

[126] Write Pipelining : https://www.cockroachlabs.com/blog/transaction-pipelining/

[127] Parallel Commit : https://www.cockroachlabs.com/blog/parallel-commits/

[128] YugabyteDB : https://blog.yugabyte.com/ysql-architecture-implementing-distributed-postgresql-in-yugabyte-db/

[129] YugabyteDB challenges CockroachDB : https://blog.yugabyte.com/yugabytedb-vs-cockroachdb-bringing-truth-to-performance-benchmark-claims-part-2/

[130] Zhihu YugabyteDB/CockroachDB debate : https://www.zhihu.com/question/449949351

[131] CockroachDB rebuts YugabyteDB : https://www.cockroachlabs.com/blog/unpacking-competitive-benchmarks/

[132] Percolator : https://github.com/pingcap/tla-plus/blob/master/Percolator/Percolator.tla

[133] TiFlash : https://docs.pingcap.com/zh/tidb/dev/tiflash-overview

[134] Greenplum's related works, GreenPlum : https://arxiv.org/pdf/2103.11080

[135] F1 Lightning : http://www.vldb.org/pvldb/vol13/p3313-yang.pdf

[136] OceanBase : https://zhuanlan.zhihu.com/p/93721603

[137] Hybrid row-column data layout : https://dbdb.io/db/oceanbase

[138] X-Engine : https://www.cs.utah.edu/~lifeifei/papers/sigmod-xengine.pdf

[139] PolarDB : https://www.usenix.org/conference/fast20/presentation/cao-wei

[140] SeaStar : https://www.scylladb.com/2016/03/18/generalist-engineer-cassandra-performance/

[141] Smart SSD paper : https://cacm.acm.org/magazines/2019/6/237002-programmable-solid-state-storage-in-future-cloud-datacenters/fulltext

[142] PolarDB Serverless : http://www.cs.utah.edu/~lifeifei/papers/polardbserverless-sigmod21.pdf

[143] AnalyticDB : http://www.vldb.org/pvldb/vol12/p2059-zhan.pdf

[144] Pangu : https://www.alibabacloud.com/blog/pangu%E2%80%94the-highperformance-distributed-file-system-by-alibaba-cloud_594059

[145] Fuxi : http://www.vldb.org/pvldb/vol7/p1393-zhang.pdf

[146] YARN : https://www.cnblogs.com/liangzilx/p/14837562.html

[147] Lambda architecture : https://www.cnblogs.com/listenfwind/p/13221236.html

[148] ClickHouse : https://clickhouse.com/docs/en/development/architecture/

[149] MergeTree : https://developer.aliyun.com/article/762092

[150] AWS Redshift, Warmpools : https://assets.amazon.science/93/e0/a347021a4c6fbbccd5a056580d00/sigmod22-redshift-reinvented.pdf

[151] AWS Nitro : https://aws.amazon.com/ec2/nitro/

[152] Serial Safe Net : https://arxiv.org/pdf/1605.04292.pdf

[153] Log is database 1 : https://zhuanlan.zhihu.com/p/33603518

[154] Log is database 2 : https://zhuanlan.zhihu.com/p/338582762

[155] Log is database 3 : https://zhuanlan.zhihu.com/p/151086982

[156] AWS Aurora Multi-master : https://www.allthingsdistributed.com/2019/03/Amazon-Aurora-design-cloud-native-relational-database.html

[157] CORFU : https://blog.acolyer.org/2017/05/02/corfu-a-distributed-shared-log/

[158] Delos : https://www.usenix.org/system/files/osdi20-balakrishnan.pdf

[159] Helios Indexing, Helios : http://www.vldb.org/pvldb/vol13/p3231-potharaju.pdf

[160] FoundationDB : https://www.foundationdb.org/files/fdb-paper.pdf

[161] HyderDB : http://www.cs.cornell.edu/~blding/pub/hyder_sigmod_2015.pdf

[162] HyPer : https://hyper-db.de/

[163] Vectorized query execution : https://www.vldb.org/pvldb/vol11/p2209-kersten.pdf

[164] LLVM : https://stackoverflow.com/questions/2354725/what-exactly-is-llvm

[165] Morsel-driven execution scheduling : https://db.in.tum.de/~leis/papers/morsels.pdf

[166] SAP HANA : http://sites.computer.org/debull/A12mar/hana.pdf

[167] MemSQL : https://www.singlestore.com/blog/revolution/

[168] GemFire used by 12306.cn : https://blog.csdn.net/u014756827/article/details/102610104

[169] Hekaton : https://www.microsoft.com/en-us/research/publication/hekaton-sql-servers-memory-optimized-oltp-engine/

[170] Bw-Tree : https://www.cs.cmu.edu/~huanche1/publications/open_bwtree.pdf

[171] Page Mapping Table, Bw-tree : https://www.microsoft.com/en-us/research/publication/the-bw-tree-a-b-tree-for-new-hardware/

[172] LLAMA : https://db.disi.unitn.eu//pages/VLDBProgram/pdf/research/p853-levandoski.pdf

[173] DocumentDB : https://www.vldb.org/pvldb/vol8/p1668-shukla.pdf

[174] Project Siberia : http://www.vldb.org/pvldb/vol6/p1714-kossmann.pdf

[175] Offline : https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/p1016-eldawy.pdf

[176] ART tree : https://db.in.tum.de/~leis/papers/ART.pdf

[177] Masstree : https://pdos.csail.mit.edu/papers/masstree:eurosys12.pdf

[178] Be-tree : https://www.usenix.org/conference/fast15/technical-sessions/presentation/jannen

[179] VMWare copy files : https://www.usenix.org/conference/fast20/presentation/zhan

[180] BloomFilter : http://oserror.com/backend/bloomfilter/

[181] SuRF : https://db.cs.cmu.edu/papers/2018/mod601-zhangA-hm.pdf

[182] FaRM : https://www.microsoft.com/en-us/research/project/farm/

[183] A1 : https://arxiv.org/abs/2004.05712

[184] DCQCN : https://blog.csdn.net/hithj_cainiao/article/details/117292144

[185] Silo : https://wzheng.github.io/silo.pdf

[186] Manycore : https://taesoo.kim/pubs/2016/min:fxmark.pdf

[187] Linux Kernel manycore, Sloppy Counter : https://pdos.csail.mit.edu/papers/linux:osdi10.pdf

[188] Filesystems manycore : https://taesoo.kim/pubs/2016/min:fxmark-slides.pdf

[189] Epoch-based Reclamation : https://aturon.github.io/blog/2015/08/27/epoch/#epoch-based-reclamation

[190] Flat Combining : https://www.cs.bgu.ac.il/~hendlerd/papers/flat-combining.pdf

[191] NetApp Waffinity : https://www.usenix.org/conference/osdi16/technical-sessions/presentation/curtis-maury

[192] RocksDB : http://rocksdb.org/

[193] KV backend in many systems : https://en.wikipedia.org/wiki/RocksDB

[194] MySQL MyRocks, RocksDB : https://vldb.org/pvldb/vol13/p3217-matsunobu.pdf

[195] TiDB on RocksDB : https://docs.pingcap.com/tidb/dev/rocksdb-overview/

[196] BlueStore and RocksDB : http://www.yangguanjun.com/2018/10/25/ceph-bluestore-rocksdb-analyse/

[197] RocksDB FAQ : http://rocksdb.org/docs/support/faq.html

[198] Universal Compaction : https://github.com/facebook/rocksdb/wiki/Universal-Compaction

[199] Remote Compaction : https://zhuanlan.zhihu.com/p/419766888

[200] PebblesDB : https://www.cs.utexas.edu/~vijay/papers/pebblesdb-sosp17-slides.pdf

[201] SST "Guards" : https://vigourtyy-zhg.blog.csdn.net/article/details/109005795

[202] MongoDB : https://engineering.mongodb.com/papers

[203] IPO : https://www.cnbc.com/2017/10/19/mongodb-mdb-ipo-stock-price-on-first-trading-day.html

[204] HBase : https://segmentfault.com/a/1190000019959411

[205] ZooKeeper : https://mikechen.cc/4657.html

[206] Replicated State Machine : https://www.youtube.com/watch?v=TWp6H7mb09A

[207] Percolator : https://research.google/pubs/pub36726/

[208] ByteSQL : https://mp.weixin.qq.com/s/DvUBnWBqb0XGnicKUb-iqg

[209] Bytable : https://mp.weixin.qq.com/s/oV5F_K2mmE_kK77uEZSjLg

[210] Lindorm : https://zhuanlan.zhihu.com/p/407175099

[211] Cassandra : https://www.cs.cornell.edu/projects/ladis2009/papers/lakshman-ladis2009.pdf

[212] Dynamo : http://docs.huihoo.com/amazon/Dynamo-Amazon-Highly-Available-Key-Value-Store.pdf

[213] DynamoDB : https://www.allthingsdistributed.com/2012/01/amazon-dynamodb.html

[214] Paper, Predictable performance, Bi-modality : https://www.usenix.org/conference/atc22/presentation/elhemali

[215] Gossip : http://kaiyuan.me/2015/07/08/Gossip/

[216] Consistent Hashing : https://www.toptal.com/big-data/consistent-hashing

[217] Service Fabric : https://dl.acm.org/doi/pdf/10.1145/3190508.3190546

[218] Geospatial data : https://www.baeldung.com/elasticsearch-geo-spatial

[219] ElasticSearch scaleout : https://www.cnblogs.com/sgh1023/p/15691061.html

[220] ELK stack : https://www.elastic.co/what-is/elk-stack

[221] InfluxDB : https://www.influxdata.com/_resources/techpapers-new/

[222] OpenTSDB : https://zhuanlan.zhihu.com/p/111511463

[223] Prometheus : https://logz.io/blog/prometheus-influxdb/

[224] InfluxDB IoT : https://www.influxdata.com/blog/how-influxdb-iot-data/

[225] Graphene : https://www.usenix.org/conference/fast17/technical-sessions/presentation/liu

[226] GraphLab : https://arxiv.org/ftp/arxiv/papers/1408/1408.2041.pdf

[227] Neo4J : https://neo4j.com/

[228] ArangoDB : https://www.arangodb.com/

[229] JSON document graph : https://www.g2.com/categories/graph-databases

[230] OrientDB : http://www.enotes.vip/index.php/tz_enotes/Article/showArticleReader.html?art_id=513

[231] Multi-model database : https://db-engines.com/en/system/ArangoDB%3BNeo4j%3BOrientDB

[232] MySQL : https://www.usenix.org/system/files/conference/atc13/atc13-bronson.pdf

[233] FaRM A1 : https://ashamis.github.io/files/A1-A-Distributed-In-Memory-Graph-Database.pdf

[234] AWS Neptune : https://aws.amazon.com/neptune/

[235] CosmosDB : https://azure.microsoft.com/en-us/blog/a-technical-overview-of-azure-cosmos-db/

[236] ByteGraph : https://www.vldb.org/pvldb/vol15/p3306-li.pdf

[237] TerarkDB : https://www.zhihu.com/question/46787984

[238] Gremlin API : https://tinkerpop.apache.org/gremlin.html

[239] Apache Hudi : https://zhuanlan.zhihu.com/p/450041140

[240] Datalake contemporaries : https://www.slideshare.net/databricks/a-thorough-comparison-of-delta-lake-iceberg-and-hudi

[241] Delta Lake : https://databricks.com/wp-content/uploads/2020/08/p975-armbrust.pdf

[242] Apache Iceberg : https://www.dremio.com/resources/guides/apache-iceberg-an-architectural-look-under-the-covers/

[243] Lakehouse : https://databricks.com/blog/2020/01/30/what-is-a-data-lakehouse.html

[244] F1 Query : http://www.vldb.org/pvldb/vol11/p1835-samwel.pdf

[245] F1 : https://static.googleusercontent.com/media/research.google.com/en//pubs/archive/41344.pdf

[246] Kafka Transactional : https://assets.confluent.io/m/2aaa060edb367628/original/20210504-WP-Consistency_and_Completeness_Rethinking_Optimized_Distributed_Stream_Processing_in_Apache_Kafka-pdf.pdf

[247] Kappa architecture : https://blog.twitter.com/engineering/en_us/topics/infrastructure/2021/processing-billions-of-events-in-real-time-at-twitter-

[248] Spark, RDD : https://spark.apache.org/docs/latest/rdd-programming-guide.html

[249] Spark stream processing : https://spark.apache.org/docs/latest/streaming-programming-guide.html

[250] Stream processing contemporaries : https://medium.com/@chandanbaranwal/spark-streaming-vs-flink-vs-storm-vs-kafka-streams-vs-samza-choose-your-stream-processing-91ea3f04675b

[251] Flink : https://flink.apache.org/

[252] Checkpointed 2PC exactly-once : https://www.infoq.com/news/2021/11/exactly-once-uber-flink-kafka/

[253] Ack by XOR of path nodes : https://hps.vi4io.org/_media/teaching/wintersemester_2017_2018/bd1718-11-streams.pdf#20

[254] NOVA : https://www.usenix.org/conference/fast16/technical-sessions/presentation/xu

[255] ART and hashtable : https://bigdata.uni-saarland.de/publications/ARCD15.pdf

[256] Level Hashing : https://www.usenix.org/conference/osdi18/presentation/zuo

[257] Orion : https://www.usenix.org/system/files/fast19-yang.pdf

[258] Octopus : https://www.usenix.org/conference/atc17/technical-sessions/presentation/lu

[259] DAX : https://blog.csdn.net/maokelong95/article/details/107195192

[260] PMEM guide, PMEM commit protocols : https://www.usenix.org/system/files/login/articles/login_summer17_07_rudoff.pdf

[261] SplitFS : https://arxiv.org/abs/1909.10123

[262] Kuco : https://www.usenix.org/conference/fast21/presentation/chen-youmin

[263] ZoFS : https://ipads.se.sjtu.edu.cn/_media/publications/dongsosp19-rev.pdf

[264] AWS S3 : https://docs.snowflake.com/en/user-guide/data-load-s3.html

[265] Snowflake went IPO : https://edition.cnn.com/2020/09/16/investing/snowflake-ipo/index.html

[266] Service Mesh : https://istio.io/latest/about/service-mesh/

[267] Envoy : https://istio.io/latest/docs/ops/deployment/architecture/

[268] Spring Cloud : https://xie.infoq.cn/article/2baee95d42ed7f8dd83cec170

[269] Dominant Resource Fairness : https://cs.stanford.edu/~matei/papers/2011/nsdi_drf.pdf

[270] Cloud Resource Scheduling : https://www.researchgate.net/publication/293329163_A_Survey_on_Resource_Scheduling_in_Cloud_Computing_Issues_and_Challenges

[271] YARN : https://mp.weixin.qq.com/s/9A0z0S9IthG6j8pZe6gCnw

[272] 2DFQ : https://cs.brown.edu/~jcmace/papers/mace162dfq.pdf

[273] Quasar : http://csl.stanford.edu/~christos/publications/2014.quasar.asplos.pdf

[274] CGroup : https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html/managing_monitoring_and_updating_the_kernel/using-cgroups-v2-to-control-distribution-of-cpu-time-for-applications_managing-monitoring-and-updating-the-kernel

[275] K8S scheduling : https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/

[276] Ceph QoS : https://docs.ceph.com/en/latest/rados/configuration/mclock-config-ref/

[277] MClock : https://www.usenix.org/legacy/event/osdi10/tech/full_papers/Gulati.pdf

[278] Leaky bucket : https://blog.51cto.com/leyew/860302

[279] Heracles : https://static.googleusercontent.com/media/research.google.com/en//pubs/archive/43792.pdf

[280] Cost Modeling : https://github.com/pingcap/tidb/blob/master/planner/core/task.go#L260

[281] Comprehensive cost modeling methods : https://15721.courses.cs.cmu.edu/spring2020/schedule.html#apr-15-2020

[282] Akkio : https://www.usenix.org/conference/osdi18/presentation/annamalai

[283] Taiji : https://research.facebook.com/publications/taiji-managing-global-user-traffic-for-large-scale-internet-services-at-the-edge/

[284] SocialHash : https://blog.acolyer.org/2016/05/25/socialhash-an-assignment-framework-for-optimizing-distributed-systems-operations-on-social-networks/

[285] Hyperspace : https://www.microsoft.com/en-us/research/publication/hyperspace-the-indexing-subsystem-of-azure-synapse/

[286] SLIK : https://www.usenix.org/system/files/conference/atc16/atc16_paper-kejriwal.pdf

[287] RAMCloud : https://ramcloud.atlassian.net/wiki/spaces/RAM/pages/6848671/RAMCloud+Papers

[288] HBase Secondary Index : http://ceur-ws.org/Vol-1810/DOLAP_paper_10.pdf

[289] LSM-tree survey : https://arxiv.org/pdf/1812.07527.pdf

[290] Facebook Owl : https://www.facebook.com/atscaleevents/videos/2897218060568137/?t=739

[291] Copyset : https://www.usenix.org/conference/atc13/technical-sessions/presentation/cidon

[292] MAPX : https://www.usenix.org/conference/fast20/presentation/wang-li

[293] HDFS : https://vanducng.dev/2020/12/05/Compact-multiple-small-files-on-HDFS/

[294] Distributed Transactions : https://mp.weixin.qq.com/s/HLIiUc6ZwGgVjZu7VJEzWQ

[295] Epoch : https://wongxingjun.github.io/2015/05/18/Paxos%E7%AE%97%E6%B3%95%E7%9A%84%E4%B8%80%E7%A7%8D%E7%AE%80%E5%8D%95%E7%90%86%E8%A7%A3/

[296] Fencing token : https://martin.kleppmann.com/2016/02/08/how-to-do-distributed-locking.html

[297] Raft, Leader Paxos : https://raft.github.io/

[298] Vector clocks : https://newbiettn.github.io/2014/05/03/lamport-clock-vs-vector-clock/

[299] Atomic disk sector write : https://www.sqlite.org/atomiccommit.html

[300] Atomic memory pointer switch, 64-bit reads/writes are atomic : https://stackoverflow.com/questions/78277/how-to-guarantee-64-bit-writes-are-atomic

[301] Wound-wait : https://cloud.google.com/spanner/docs/whitepapers/life-of-reads-and-writes

[302] C++ memory model : https://www.youtube.com/watch?v=A_vAG6LIHwQ

[303] Programming locks : https://compas.cs.stonybrook.edu/~nhonarmand/courses/fa17/cse306/slides/11-locks.pdf

[304] B+-tree locking techniques, 数据库内核月报 B+tree : http://mysql.taobao.org/monthly/2018/09/01/

[305] Linux Kernel synchronization : https://mirrors.edge.kernel.org/pub/linux/kernel/people/christoph/gelato/gelato2005-paper.pdf

[306] Database transactions, ARIES, 阿莱克西斯 ARIES : https://zhuanlan.zhihu.com/p/143173278

[307] FFS : https://www.ece.cmu.edu/~ganger/papers/usenix2000.pdf

[308] Optimistic Crash Consistency : https://research.cs.wisc.edu/adsl/Publications/optfs-sosp13.pdf

[309] Out-of-order commit : https://www.zhihu.com/question/278984902

[310] Megastore, Google Megastore : http://cidrdb.org/cidr2011/Papers/CIDR11_Paper32.pdf

[311] Chain Replication : https://sigops.org/s/conferences/sosp/2011/current/2011-Cascais/printable/11-calder.pdf

[312] MySQL BinLog Replication : https://hevodata.com/learn/mysql-binlog-based-replication/

[313] Compensation Transaction : https://developer.jboss.org/docs/DOC-48610

[314] Redis replication : https://redis.io/docs/manual/replication/

[315] RBD diff : https://ceph.io/en/news/blog/2013/incremental-snapshots-with-rbd/

[316] Google Spanner : https://cloud.google.com/spanner/docs/replication

[317] TrueTime : https://static.googleusercontent.com/media/research.google.com/en//pubs/archive/45855.pdf

[318] CockroachDB : https://www.cockroachlabs.com/blog/geo-partitioning-one/

[319] Flashcache : https://github.com/facebookarchive/flashcache/blob/master/doc/flashcache-doc.txt

[320] B+-tree : https://www.zhihu.com/question/516912481/answer/2403713321

[321] TMO : https://www.cs.cmu.edu/~dskarlat/publications/tmo_asplos22.pdf

[322] PMEM empirical guide : https://www.usenix.org/conference/fast20/presentation/yang

[323] Memory page swap : https://github.com/torvalds/linux/blob/master/mm/workingset.c

[324] Google G-SWAP : https://research.google/pubs/pub48551/

[325] REMIX LSM-tree : https://zhuanlan.zhihu.com/p/357024916

[326] Project Catapult : https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/Catapult_ISCA_2014.pdf

[327] SmartNICs : https://zhuanlan.zhihu.com/p/393393682

[328] IPU : https://www.forbes.com/sites/karlfreund/2021/08/02/nvidia-dpu--intel-ipu-game-changers-or-just-smart-nics/

[329] DPU : https://en.wikipedia.org/wiki/Data_processing_unit

[330] Smart SSD : https://www.youtube.com/watch?v=_8gEmK1L4EY

[331] Late materialization : https://web.stanford.edu/class/cs245/win2020/readings/c-store-compression.pdf

[332] SIMD vectorization and JIT compile : https://15721.courses.cs.cmu.edu/spring2020/papers/16-vectorization2/p2209-kersten.pdf

[333] Succinct data structures : https://www2.eecs.berkeley.edu/Pubs/TechRpts/2019/EECS-2019-141.pdf

[334] Parquet : https://github.com/apache/parquet-format

[335] NVMe protocol : https://www.seagate.com/files/www-content/product-content/ssd-fam/nvme-ssd/nytro-xf1440-ssd/_shared/docs/an-introduction-to-nvme-tp690-1-1605us.pdf

[336] FStream : https://www.usenix.org/conference/fast18/presentation/rho

[337] Apache ORC : https://medium.com/data-engineer-things/demystify-hadoop-data-formats-avro-orc-and-parquet-e428709cf3bb

[338] Z-Order : https://zhuanlan.zhihu.com/p/491256487

[339] "tiering" vs "leveling" : https://zhuanlan.zhihu.com/p/112574579

[340] Data clustering & data skipping : https://zhuanlan.zhihu.com/p/354334895

[341] TRIAD : https://github.com/epfl-labos/TRIAD

[342] Scalable MVCC GC paper : http://www.vldb.org/pvldb/vol13/p128-bottcher.pdf

[343] Compression algorithm selection taxonomy : https://www.cs.umd.edu/~abadi/talks/Column_Store_Tutorial_VLDB09.pdf

[344] LZ77 : https://www.youtube.com/watch?v=jVcTrBjI-eE

[345] Anti-entropy stage : https://stackoverflow.com/questions/55547113/why-to-combine-huffman-and-lz77

[346] FSST string symbol table : https://www.vldb.org/pvldb/vol13/p2649-boncz.pdf

[347] Zstd dictionary mode : https://ayende.com/blog/189954-A/random-access-compression-and-zstd

[348] LZ-End : https://users.dcc.uchile.cl/~gnavarro/ps/dcc10.1.pdf

[349] FiniteStateEntropy : https://github.com/Cyan4973/FiniteStateEntropy

[350] Perfect hashing : https://en.wikipedia.org/wiki/Perfect_hash_function

[351] False sharing : https://trishagee.com/2011/07/22/dissecting_the_disruptor_why_its_so_fast_part_two__magic_cache_line_padding/

[352] Lock coupling : https://15721.courses.cs.cmu.edu/spring2016/papers/a16-graefe.pdf

[353] Sketch structures : https://dsf.berkeley.edu/cs286/papers/synopses-fntdb2012.pdf

[354] Clustered into index : https://docs.microsoft.com/en-us/sql/relational-databases/indexes/clustered-and-nonclustered-indexes-described?view=sql-server-ver15

[355] Cuckoo hashing : https://en.wikipedia.org/wiki/Cuckoo_hashing

[356] HotRing : https://www.usenix.org/system/files/fast20-chen_jiqiang.pdf

[357] Consistent Hashing : https://medium.com/system-design-blog/consistent-hashing-b9134c8a9062

[358] Skiplist : https://en.wikipedia.org/wiki/Skip_list

[359] Radix tree : https://en.wikipedia.org/wiki/Radix_tree

[360] Memory management : https://lwn.net/Articles/175432/

[361] Red-back tree : https://en.wikipedia.org/wiki/Red%E2%80%93black_tree

[362] AVL tree : https://stackoverflow.com/questions/5288320/why-is-stdmap-implemented-as-a-red-black-tree

[363] Rust implements ordered map with B-tree : https://www.zhihu.com/question/516912481

[364] B+-tree has another Rust discussion : https://github.com/rust-lang/rust/issues/27090

[365] ARIES : https://cs.stanford.edu/people/chrismre/cs345/rl/aries.pdf

[366] B+-tree locking techniques : https://15721.courses.cs.cmu.edu/spring2017/papers/06-latching/a16-graefe.pdf

[367] Bitmap index : https://www.oracle.com/technical-resources/articles/sharma-indexes.html

[368] Bit-vector compression : https://www.cs.umd.edu/~abadi/talks/Column_Store_Tutorial_VLDB09.pdf#page=52

[369] Inverted index : https://codingexplained.com/coding/elasticsearch/understanding-the-inverted-index-in-elasticsearch

[370] TF-IDF : https://en.wikipedia.org/wiki/Tf%E2%80%93idf

[371] PageRank algorithm : https://en.wikipedia.org/wiki/PageRank

[372] Eigenvector : https://blog.csdn.net/sdgihshdv/article/details/77340966

[373] Succinct wiki : https://en.wikipedia.org/wiki/Succinct_data_structure

[374] FM-index : https://www.youtube.com/watch?v=kvVGj5V65io

[375] Burrows-Wheeler Transform : https://www.youtube.com/watch?v=4n7NPk5lwbI

[376] Compressed Suffix Array, SuccinctStore paper : https://www.usenix.org/conference/nsdi15/technical-sessions/presentation/agarwal

[377] Succinct Trie : https://www.cs.cmu.edu/~huanche1/publications/surf_paper.pdf

[378] TerakaDB/ToplingDB : https://www.zhihu.com/question/46787984/answer/103639893

[379] Spark RDD : https://databricks.com/blog/2015/11/10/succinct-spark-from-amplab-queries-on-compressed-rdds.html

[380] GitHub AMPLab/Succinct : https://github.com/amplab/succinct

[381] GitHub simongog/sdsl-lite : https://github.com/simongog/sdsl-lite

[382] Genomes compression : https://academic.oup.com/bioinformatics/article/27/21/2979/217176?view=extract

[383] LZ-End : https://drops.dagstuhl.de/opus/volltexte/2017/7847/pdf/LIPIcs-ESA-2017-53.pdf

[384] Write through : https://www.zhihu.com/question/319817091

[385] InfiniFS : https://zhuanlan.zhihu.com/p/492210459

[386] Social Hashing : https://blog.acolyer.org/2019/11/15/facebook-taiji/

[387] RAIDShield : https://www.usenix.org/system/files/conference/fast15/fast15-paper-ma.pdf

[388] UBER : https://www.jedec.org/standards-documents/dictionary/terms/uncorrectable-bit-error-rate-uber

[389] CRC wiki : https://en.wikipedia.org/wiki/Cyclic_redundancy_check

[390] CRC lecture : https://www.cs.princeton.edu/courses/archive/spring18/cos463/lectures/L08-error-control.pdf

[391] AWS AZ : https://cloud.netapp.com/blog/aws-availability-using-single-or-multiple-availability-zones

[392] Azure redundancy : https://docs.microsoft.com/en-us/azure/storage/common/storage-redundancy

[393] Observational Difference : https://www.microsoft.com/en-us/research/wp-content/uploads/2017/06/paper-1.pdf

[394] Exponential distribution : http://web.stanford.edu/~lutian/coursepdf/unit1.pdf

[395] Query optimizers : https://mp.weixin.qq.com/s?__biz=MzI5Mjk3NDUyNA==&mid=2247483895&idx=1&sn=05b687a465f5e705dbebfdccaf478f4b

[396] The power of two random choices : https://brooker.co.za/blog/2012/01/17/two-random.html

[397] Queuing theory : https://lrita.github.io/images/posts/math/%E6%8E%92%E9%98%9F%E8%AE%BA%E5%8F%8A%E5%85%B6%E5%BA%94%E7%94%A8%E6%B5%85%E6%9E%90.pdf

[398] NyxCache paper : https://www.usenix.org/conference/fast22/presentation/wu

[399] DPDK : https://www.dpdk.org/

[400] SPDK : https://spdk.io/

[401] BlueFS : https://zhuanlan.zhihu.com/p/46362124

[402] Computational SSD drives : https://www.usenix.org/system/files/fast22-qiao.pdf

[403] NVLink : https://ieeexplore.ieee.org/document/7924274

[404] OpenTelemetry : https://opentelemetry.io/docs/concepts/

[405] Google Dapper : https://research.google/pubs/pub36356/

[406] Queuing layout : https://zhuanlan.zhihu.com/p/22124514

[407] DRAM banks : https://zhuanlan.zhihu.com/p/539717599

[408] Parallelism at Plane level : https://blog.51cto.com/alanwu/1544227

[409] Speculative execution : https://www.usenix.org/conference/fast22/presentation/lv

[410] Coyote : https://github.com/microsoft/coyote

[411] TLA+ : https://lamport.azurewebsites.net/tla/book.html

[412] Interactive latency : https://colin-scott.github.io/personal_website/research/interactive_latency.html

[413] Power component comparison : https://www.researchgate.net/figure/Power-consumption-of-CPU-memory-network-and-disk-for-various-computing-processes-19_fig1_327203171

[414] Clos network architecture : https://www.youtube.com/watch?v=XrnATy3AvpA

[415] OSPF, RIP, BGP : https://www.youtube.com/watch?v=KjNYEzEBRD8

[416] ECMP : https://en.wikipedia.org/wiki/Equal-cost_multi-path_routing

[417] WCMP : https://www.researchgate.net/publication/266657103_WCMP_Weighted_cost_multipathing_for_improved_fairness_in_data_centers

[418] ECWide : https://www.usenix.org/conference/fast21/presentation/hu

[419] Google Jupiter Rising : https://conferences.sigcomm.org/sigcomm/2015/pdf/papers/p183.pdf

[420] Google Orion SDN : https://www.usenix.org/conference/nsdi21/presentation/ferguson

[421] Dragonfly topology : https://static.googleusercontent.com/media/research.google.com/en//pubs/archive/34926.pdf

[422] Dragonfly+ topology : https://www.researchgate.net/profile/Eitan-Zahavi/publication/313341364_Dragonfly_Low_Cost_Topology_for_Scaling_Datacenters/links/5a30c4baaca27271ec8a1201/Dragonfly-Low-Cost-Topology-for-Scaling-Datacenters.pdf

[423] Google B4 After : https://dl.acm.org/doi/pdf/10.1145/3230543.3230545

[424] Optical Circuit Switch : https://arxiv.org/abs/2208.10041

[425] Google Jupiter Evolving : https://research.google/pubs/pub51587/

[426] OpenFlow : https://medium.com/@fiberoptics/openvswitch-and-openflow-what-are-they-whats-their-relationship-d0ccd39b9a5c

[427] Traffic Engineering : https://www.youtube.com/watch?v=Hfl-i56hZUg&loop=0

[428] OpenDaylight : https://www.fiber-optic-transceiver-module.com/openstack-vs-opendaylight-vs-openflow-vs-openvswitch-whatre-their-relations.html

[429] Openstack Neutron : https://docs.openstack.org/neutron/latest/

[430] Open vSwitch : https://en.wikipedia.org/wiki/Open_vSwitch

[431] Control plane network : https://www.usenix.org/system/files/nsdi21-ferguson.pdf

[432] Google B4 Experience : https://dl.acm.org/doi/pdf/10.1145/2486001.2486019

[433] Google datacenter network : https://www.youtube.com/watch?v=kythGOICErQ&t=1244s

[434] F5 BIG-IP : https://www.f5.com/glossary/load-balancer

[435] Google Maglev : https://www.usenix.org/conference/nsdi16/technical-sessions/presentation/eisenbud

[436] UCloud Vortex : https://www.ucloud.cn/yun/34767.html

[437] NGINX : https://www.nginx.com/products/nginx/high-availability/

[438] HAProxy : https://www.digitalocean.com/community/tutorials/how-to-set-up-highly-available-haproxy-servers-with-keepalived-and-reserved-ips-on-ubuntu-14-04

[439] LVS : https://en.wikipedia.org/wiki/Linux_Virtual_Server

[440] Keepalived : http://www.keepalived.org/

[441] OSI model : https://www.imperva.com/learn/application-security/osi-model/

[442] NATs : https://en.wikipedia.org/wiki/Network_address_translation#Type_of_NAT_and_NAT_traversal,_role_of_port_preservation_for_TCP

[443] Sticky session : https://www.imperva.com/learn/availability/sticky-session-persistence-and-cookies/

[444] API gateway : https://microservices.io/patterns/apigateway.html

[445] Direct server return : https://docs.bluecatnetworks.com/r/DNS-Edge-Deployment-Guide/How-DSR-load-balancing-works

[446] ECN : https://en.wikipedia.org/wiki/Explicit_Congestion_Notification

[447] PFC : https://en.wikipedia.org/wiki/Ethernet_flow_control

[448] Head-of-line blocking : https://en.wikipedia.org/wiki/Head-of-line_blocking

[449] DCQCN : https://conferences.sigcomm.org/sigcomm/2015/pdf/papers/p523.pdf

[450] RoCEv2, CNP : https://en.wikipedia.org/wiki/RDMA_over_Converged_Ethernet

[451] QCN : https://1.ieee802.org/dcb/802-1qau/

[452] DCTCP : https://www.microsoft.com/en-us/research/wp-content/uploads/2017/01/dctcp-sigcomm2010.pdf

[453] Slow start : https://en.wikipedia.org/wiki/TCP_congestion_control

[454] BBR : https://www.zhihu.com/question/53559433

[455] InfiniBand : https://en.wikipedia.org/wiki/InfiniBand

[456] RDMA design guidelines : https://www.usenix.org/system/files/conference/atc16/atc16_paper-kalia.pdf

[457] VxLAN : https://en.wikipedia.org/wiki/Virtual_Extensible_LAN

[458] GRE : https://en.wikipedia.org/wiki/Generic_Routing_Encapsulation

[459] Nitro card : https://docs.aws.amazon.com/whitepapers/latest/security-design-of-aws-nitro-system/the-components-of-the-nitro-system.html

[460] SR-IOV : https://learn.microsoft.com/en-us/windows-hardware/drivers/network/overview-of-single-root-i-o-virtualization--sr-iov-

[461] Azure SmartNIC : https://www.microsoft.com/en-us/research/project/azure-smartnic/

[462] RabbitMQ : https://www.rabbitmq.com/

[463] Varint encoding : https://developers.google.com/protocol-buffers/docs/encoding

[464] Protobuf : https://en.wikipedia.org/wiki/Protocol_Buffers

[465] Bond : http://microsoft.github.io/bond/manual/bond_cs.html

[466] Thrift : https://stackoverflow.com/questions/69316/biggest-differences-of-thrift-vs-protocol-buffers

[467] FlatBuffers : https://stackoverflow.com/questions/25356551/whats-the-difference-between-protocol-buffers-and-flatbuffers

[468] Apache Arrow : https://stackoverflow.com/questions/56472727/difference-between-apache-parquet-and-arrow

[469] Apache Avro : https://www.clairvoyant.ai/blog/big-data-file-formats

[470] Client Protocol Redesign : https://15721.courses.cs.cmu.edu/spring2020/papers/11-networking/p1022-muehleisen.pdf

[471] Btrfs compression COW : https://superuser.com/questions/858219/btrfs-filesystem-compression-and-copy-on-write

[472] Ceph BlueStore compression : https://www.spinics.net/lists/ceph-devel/msg28846.html

[473] CMDB : https://en.wikipedia.org/wiki/Configuration_management_database

[474] AWS Redshift ATO : https://aws.amazon.com/blogs/big-data/automate-your-amazon-redshift-performance-tuning-with-automatic-table-optimization/

[475] Azure SQL Database auto tuning : https://learn.microsoft.com/en-us/azure/azure-sql/database/automatic-tuning-overview?view=azuresql

[476] OtterTune : https://ottertune.com/features/

[477] Why ClickHouse is fast : https://clickhouse.tech/docs/en/faq/general/why-clickhouse-is-so-fast/

[478] ElasticSearch : https://en.wikipedia.org/wiki/Elasticsearch

[479] Premature Optimization : https://stackify.com/premature-optimization-evil/

[480] Case Interview Examples : https://www.craftingcases.com/case-interview-examples/ 

[481] MECE: https://strategyu.co/wtf-is-mece-mutually-exclusive-collectively-exhaustive/

[482] Clique : https://en.wikipedia.org/wiki/Clique_(graph_theory)

(封面图片 by SBA73, CC BY-SA 2.0: https://99percentinvisible.org/episode/la-sagrada-familia/)
