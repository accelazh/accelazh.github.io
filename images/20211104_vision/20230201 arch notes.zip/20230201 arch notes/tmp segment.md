## Data organization

Traditionally "data organization" talks about physical columnar/row-wise data layouts in databases. I choose to view data organization from a broader perspective which is divided by purposes.

  * __Durability tier__. The basic need to organize data in a storage system is to make it durable. __Replication__ is common, on the cost of storage efficiency, yet vulnerable as corruption can be simultaneously replicated. Replication also couples with performance tier to balance reads with extra replicas. __Erasure Coding (EC)__ reduces storage space, improves durability, on the cost of data reconstruct. __Consistency__ is a common issue that accompanies replication. __End-to-end CRC__ and __periodical scrubbing__ are necessary to protect against corruption happens on write path, data transformation, or silent data at rest. __Backup__, __geo-replication__ are standard setups for disaster recovery, while __time travel__ is handy to recover manual errors by restoring an early version.

  * __Query tier__. Disk data needs to support reads and update. Common accesses are __sequential/random reads__, __appends__, __updates (or read-modify-write)__ talked in storage systems, and __point/range queries__, __scans__, __inserts__, __updates (or update-after-query)__ talked in databases. Traditionally, disk data serves both durability tier and query tier coupled, which incurs cost in write path to maintain read-optimized format. Separating read path and write path can help, or move read path entirely to __performance tier__, e.g. in-memory database. Query tier can further specialize for __OLTP__, __OLAP__ and __Datalake__ that share main techniques but vary at query patterns, consistency, data scale, and structured data.

  * __Performance tier__. Commonly they are extra data copies to balance reads, an SSD tier for caching (or also serves part of durability), PMEM staging area to absorb and sequentialize repeated random writes, plain memory caching, or in-memory DB that moves all computation to memory. When used as cache, SSD or memory can target small blocks rather than entire chunks from disk, see [Data caching section](.). Data organized in memory is more attached to indexes, unlike on disk, see [Data indexing section](.).

  * __Scaleout tier__. To cope with increasing volume and high throughput targets, data is __partitioned__, __replicated__, and work with __placement__ to serve from more machines. __Resource scheduling__ for heterogeneous job sizes, __load balancing__, and __migration__ follow the needs. See [Data partitioning section](.). __Consistency__ is always a problem. On single node it easily relies on CPU cache coherence, but scale-up is bottlenecked by CPU power/heat and cache coherence cost between too many cores. Coming to distributed systems, consistency of distributed transaction still incurs high networking cost, unless relaxing it with App level agreement.

Essentially, query tier carries the most DB techniques when it wants to be performant, while durability/scaleout tiers are orthogonal from it and can be offloaded to a shared storage system, and performance tier is usually addressed by caching. We focus on query tier for data organization, and discuss performance/scaleout tiers in other sections.

### Durability tier

We covered replication in [Consistency section](.). We will see more about CRC and scrubbing in [Data integrity section](.). Below we briefly expand the design space for Erasure Coding (EC).

  * __Storage overhead__. The main goal of EC is to store data with comparable durability but less storage space, compared to plain replication.

  * __Durability__. Data must be recoverable, if a set of disks went bad. Data must be available (with reconstruct) to user reads, if a set of nodes went offline.

  * __Performance__. Compared to plain replication, reading (reconstruct) EC data incurs significant cost when part of data is offline, especially the tail latency. With less storage copies, total aggregated bandwidth to serve is capped.

EC codecs have great richness in schema variety, especially combined with cluster layouts and user traffic patterns. Briefly, main schemas come from below classes

  * __Reed-Solomon Codes__. The standard textbook schemas where each data symbol is symmetrically involved in each parity symbol. The code is MDS, which means able to recover the most loss patterns given fixed storage overhead.

  * __Local-reconstruct Codes (LRC)__. To reduce bandwidth needed in reconstruct reads or data repair, part of parity symbols choose to involve less data symbols. In another word, the schema improves performance in the cost of recoverable loss patterns.

  * __Regenerating Codes__. Another approach to reduce bandwidth in reconstruction. MSR (Minimum Storage Regenerating) codes reach low bandwidth bound without penalty on storage overhead. The code construction is usually more complex and involves more computation.

### Data layout for query tier

In high level, we first capture the desired __goals__ of a data layout. Ideally we want every goal to reach optimal, which by far is impossible. Trading off between goals composes the design space.

  * __Read amplification__. To return the desired value, how many extra data reads needed in count and size? Locating the data starts from index lookup. Without fine-grain index, reads need to scan through the entire chunk. More chunks containing stale data are involved, if chunks host overlapping ranges. Ideally, if any data can be located accurately, scan is not even needed. Read amplification is possible to be __amortized by batching queries__, at a cost of latency.

  * __Write amplification__. To write a piece of data, how many extra writes needed in count and size? In-place update in an array can kick off ripple data movements if the slot is too small. Append-only systems trigger background writes for GC/compaction. Background jobs also do rewrites. Write amplification is possible to be __pushed off to offline__ from write path, at a cost of space amplification. Deletes can be treated as a special type of writes. Note extra reads can also accompany write amplification in data movement.

  * __Space amplification__. Compared to only user data, how much extra storage space is spent at query tier? This includes unclaimed stale (or deleted) values, empty slots pre-allocated for inserts, internal fragmentation inside pages/chunks, external fragmentation that skips allocation. Space amplification can naively be reduced by GC/compact more frequently, at a cost of read/write amplification. Storage space goals are critical to Cloud Storage COGS which sells by capacity.

  * __Sequentialize reads__. HDD favors sequential reads. We want the next read hits a previous prefetch, multiple reads to batch in one bigger, and range queries to map to sequential on-disk scans. We want __data locality__ to be preserved for access pattern.

  * __Sequentialize writes__. HDD/SSD favor sequential writes. Append-only systems sequentialize all writes. In-place update systems are harder, but possible with pre-allocated empty slots, or filesystem extents.

  * __Compression__. Compression is critical to storage efficiency at query tier. It also reduces amplification by transferring less data in reads/writes. Compression needs to work with encryption, where CBC (chained block cipher) can randomize identical blocks. Packing similar data together makes compression more efficient (e.g. columnar layout). Transfer overhead can be reduced by directly querying and passing compressed blocks ([late materialization][331]). Queries become even more efficient with [SIMD vectorization and JIT compile][332].

  * __Index lookup__. An ideal data layout should be easy for index lookup to serve reads or find write locations. Index structure and traversal can embed into data units, or data clustered into index. Given limited index size and granularity, data chunks can have a second level min-max sketching, zone maps, or bloomfilters. Data can also be compressed, support range query, without a separated index; see [Succinct data structures][333].

Next, we define the __data unit__, e.g. how big a block is, chunks, files. We need to think properties are enforced at which level of data unit, indexing happens at which granularity, data placement & migration unit size, etc. Listing data units from small to big:

  * __Individual key-value__, or only value if the key can be derived, e.g. incremental row id in columnar layout. This is the smallest data unit. Usually indexing every key-value at this layer is prohibitively expensive.

  * __Row group__. A file can have multiple row groups. It may still be too small for indexing, but carries itself min-max sketching and aggregation statistics. The example is [Parquet][334], or AnalyticDB row-column layout. A row group contains all columns for a set of rows, while inside the row group data is organized columnar.

  * __Chunk__. I use "Chunk" to universally donate the smallest data unit to index. An example is the "SST file" in RocksDB, where reads first locates a chunk (think of a "shabby" index here) and then full scan it (can be optimized by per row group sketching). Another example is the "page" in B+-tree index (such systems usually don't have row groups), where we need to consider record layout inside. The next example is the "block" in filesystems, which is indexed by inode trees; or "extents", where allocator assigns a larger space than asked, to append future writes.

  * __Partition__. The smallest unit to choose which server to host. It's where data starts to participant in a distributed system, and as the unit for placement, replication and migration.

  * __Data unit for classification__. Storage systems need to decide a data unit as the level for __tracking and classification__. Classification is a common problem in storage systems for efficient GC/compaction, temperature tiering, and various background jobs. __Machine Learning__ can but not much used mainly due to the metadata size and computation cost for vast tracking units. The unit of classification can either be bigger or much smaller than a partition, given the tracking cost willing to pay.

    * __Generation__. I.e. the "level" in LSM-tree or RocksDB. It marks how many GC/compaction rounds the data has went through. It __classifies__ how likely the data won't be deleted/overwritten in future. LSM-tree couples more properties with generation, e.g. chunk size, sort runs, compaction strategies; which is a design choice but not a necessity.

    * __Temperature tiering__. A tag with statistics to __classify__ how likely the data will be accessed in future with certain traffic. Efficient ways to offload cold data to cheaper storage media is critical for storage space efficiency, while quick response on sudden user reads yet needs the (asymmetric) data unit of transfer. Separating GC/compaction strategies between cold/hot is also beneficial.

    * __Workload streams__. The storage system is serving mixed user workloads. "Stream" here means to separate out the data operations from a single workload (e.g. single App, single content, single user). The concept came from [NVMe protocol][335], and an example is [FStream][336]. Practically, "stream" groups similar data together to yield better compression, dedup, to share close lifecycle in GC/compaction, and temperature.

In the next level, we abstract the __properties__ of a data layout. They constraint the physical data organization intra/inter data units, to which writes pay to maintain, and reads benefit from to speedup. Below lists properties from small to big data units. They map properties to high level goals. Applying properties and trade off between them compose the design space for various techniques.

  * At key-value level, common techniques are to __separate keys and values__ (WiscKey). Most compaction happen at keys, thus saved rewrite amplification on values (which are big). Another technique is to __dedup common key prefixes__ which saves storage space. Examples are "column family" in HBase, trie trees, and Masstree.

  * At row group level, a notable property is whether data is stored in __columnar or row format__. OLTP database favors row format, where data is organized as rows, and row piles in a page. OLAP database favors columnar format, where data is organized as columns, values from one column is stored consecutively in a row group, and then to the next column.

    * __Columnar format__. Since column packs similar data, compression is more efficient thus reduces storage space, and less read data when scan. Common OLTP workloads can hardly generate columnar format on start, thus need to pay write amplification for batch and rewrite. Querying one column and then lookup another column in one row, however incurs extra IOs and non-sequential reads, because columns are stored at different locations. Common columnar format examples are Parquet, [Apache ORC][337].

    * __Row format__. Scans involve unnecessary columns, i.e. a read amplification. Compression are less efficient compared to columnar format, and also cost read transfers. But updating/inserting can directly operate in unit of rows. Looking up all columns in one row costs only one read.

Continue with data layout __properties__. __At chunk level__, many properties are covered such as whether data is __sorted__ (or partially sorted), __overlapping__ between chunks, __cross chunk linking__, allowing __in-place updates__. They further couple with intra chunk or inter chunk. Much of LSM-tree compaction optimization is talking about this level.

  * __Sorted, intra chunk__. Examples are RocksDB SST files, or column values in columnar format, which stores records sorted. Sorting favors lookups to locate the record, allows sequential reads in range queries, ease building external index or embedding index inside file. However, since user writes in any order, sorted data cannot be obtained from start, unless either buffer in memory, or pay write amplification for rewrite. Besides, sorted data enables more efficient compression algorithm, e.g. Run-length Encoding (RLE).

    * __In-place updates__. Maintaining both intra chunk sorted and in-place update is hard. Giving up internal sorting, sort property can be __pushed off to inter chunk level__, so that read amplification is still capped, and index at chunk granularity can still be built. To absorb inserts, a chunk can pay storage space to pre-allocate empty slots, or pay extra writes to move records elsewhere.

    * __Index sort order vs data sort order__. Databases records can appear to be sorted by index (e.g. traverse B+-tree in order), but random on-disk. Though a range query saves lookup by leveraging index sort order, on-disk scan still suffers from random reads. To align on-disk data in sort order, it can pay amplification for a rewrite. Or, let index leaf level have larger chunks for sequential reads inside, and then jump to the next chunk. However, secondary indexes can hardly achieve data sort order on secondary keys, while this can be compensated by [Z-Order][338] at a cost of read amplification.

  * __Sorted, inter chunks__. The example is ["tiering" vs "leveling"][339] in RocksDB. "Leveling" requires chunks are __non-overlapping__, i.e. a sorted run, or chunks have a total sort order. It favors read to quickly locate only one chunk that needs scan. However, maintaining the inter chunk sort property requires more eagerly paying writes in compaction. In "tiering", chunks can have __overlapping__ key ranges. Breaking "sorted" property relaxes writes, but read may need to scan multiple chunks.

    * __Overlapping__. Can chunks have overlapping key ranges? This is another way to say whether inter chunk sort property is enforced.

    * __Partially sorted, inter chunks__. The example is "Guards" in PebblesDB. A guard contains multiple chunks which can overlap, but cross guards there is no overlapping. It creates a tunable balance between read/write amplification.

    * __Key assignment to chunks__ matters when maintaining the sort/overlapping property inter chunks. By partitioning keys into non-overlapping ranges (or hashing) and assigning to different chunks, it ensures chunks non-overlapping. You can see __data partitioning__ is not only for scaleout, but also a method to __separate conflict spaces__ that eases algorithm handling. Besides, it also __separates addressing space__, which reduces metadata size, as you see in [Metadata section](.).

    * __Fixed/variable sized blocks__. For example, chunks of SST files are variable sized, database pages are fixed size, and storage system may either use fixed sized or variable sized blocks. Fixed size blocks are commonly seen in traditional filesystems, updated in-place, where size variety is however handled by allocator (which can be tricky to be robust). Internal fragmentation can waste space inside blocks.  Variable sized blocks favor append-only systems and compression which outputs unpredictable size. Index metadata has to be larger, as no fixed size of tracking units.  In balance of the two: 1) The system can take a __minimal write size__ e.g. 4KB, so index metadata size is reduced even for variable sized blocks. 2) Allocate by a large "extent" rather than individual blocks, so that inside the extent it can append fixed size blocks and reduce external fragmentation.

    * __Compensation by index__. Having an index can ease chunk maintenance. If the chunk means B+-tree index pages, it needs to maintain both non-overlapping and fixed size block property. This is done by __key assignment to chunks__ guarded by the index itself. With overlapping chunks, instead of scanning all matched ones, a global tree/hash index can tell whether certain key exists in a chunk, so as bloomfilters (which is commonly used). In a word, __index compensates read amplification__.

  * __Cross chunk linking__. The example is __Forwarding pointers__ in LSM-tree that level L-1 chunks can embed pointers to level L chunks. When a read scanned level L-1 but didn't find matching records, it can follow forwarding pointers to level L, which saves scanning startover. E.g. [REMIX LSM-tree][325]. Essentially, the method is to __embed an index__ at inter chunk level. Note we also mentioned __indexing at chunk internal__, or a separate __external index__. Conceptually, index leverages __connections between data__ to build, this right happens when chunks have overlapping key ranges across LSM-tree levels.

  * __Data locality__. Data to be accessed together should be located physically close, so that a read can fetch all. This can happen at node/partition level to save cross networking, within same chunk/block to be cached as one unit, or aligned in neighbor records to benefit prefetch. An example is graph databases, where edges and vertices are accessed one by one in traversal order.

    * __[Data clustering & data skipping][340]__ as we can also call it. Data clustering means data frequently accessed together should be physically packed together, so they can be prefetched or returned in one sequential scan. It becomes tricky when trying to pack different DB table fields. An example is Z-Order. Data skipping is an opposite of data clustering that, it tries to skip as much unnecessary data during disk scan. It leverages the embedded sketching filters or indexes, and avoid clustering too much unrelated data.

Other data layout __properties__ at data unit levels of partition and classification:

  * __Partition level__. It maps to chunk level to serve individual queries. There are few other "larger scale" properties

    * __Replication__ and __placement__ affects how queries are served at distributed system level, but more proper to discuss at [Data partitioning section](.). __Colocation__ places data used together on same node to benefit prefetching and saves networking coordination cost.

    * __Interoperability__. Datalake, e.g. Delta Lake, uses open formats (Parquet, Apache ORC, JSON, CSV) for both its internal data, metadata, and transaction logs. This allows any other app to interoperate, and allows launching a new server anywhere else at cloud to resume processing.

  * __Classification level__. It maps to individual or a group of similar chunks as the tracking unit. The grouping can either be physical to locate chunks together, or logical to track similar chunks with metadata.

We can summarize data layout __properties__ by exploring two extremes, a write-optimized layout and a read-optimized layout. We can tune properties to watch the transition between the two.

  * __Write-optimized layout__. Newly updated/inserted data are sequentially appended to the end of log without any special handling. Write path has the lowest cost.

  * __Read-optimized layout__. Chunks are fully indexed at key-value granularity. Chunks are internally sorted, non-overlapping, and large enough to avoid fragmented IOs from a range query. Columnar layout if not too many cross-column lookups. Fields frequently accessed together are packed close.

  * __Transition from write-optimized to read-optimized layout__. Applying various properties, we can observe three trends: 1) introduce sort order, 2) reduce tracking granularity, 3) group similar data together

    * __Introduce sort order__. A query needs to exploit sort order to locate data more quickly and skips unrelated ones. On-disk access also benefits from sequential reads. Sorting also benefits compression such as RLE. Chunk internal sort is usually done by a rewrite. Inter chunk sort can dial from loose to tight, by directing records through guards or index.

    * __Reduce tracking granularity__. The benefits come to indexing and skipping. With smaller granularity located and more unrelated data filtered out, queries save more reads. Metadata overhead is a trade off, where low level index parts / sketching / statistics can be embedded in chunks, rather than pinned in memory. Chunks can be cut smaller, with size more balanced, and embed variety at row group level.

    * __Group similar data together__. Examples are, separating keys and values, columnar format that groups values from a single column, generation or LSM-tree levels that group data by lifecycle, temperature tiering that groups cold/hot data, workload streams that group similar data from a single workload. Such classification, either based on type rules, statistics, or Machine Learning, are effectively useful everywhere, e.g. compression, scanning, GC/compaction, lifecycle related data movements.

More about optimized layouts

  * __Space-optimized layout__. Space amplification is important to Cloud Storage COGS but less attended. Write-optimized layout hurts space efficiency due to unclaimed stale values. Read-optimized layout hurts space efficiency, if it keeps internal fragmentation in pages, blocks, or pre-allocated empty slots. Efficient compression is also required. Space-optimized layout can be a columnar layout with closely packed records, which seems can be achieved together with read-optimized layout. If we accept rewrites, we also absorb newly ingested data by write-optimized layout.

  * __Balanced-optimized layout__. Considering the cost of GC/compaction, we can hardly achieve both write/read-optimized simultaneously. A balanced layout is worthwhile, and it is only __optimized__ when tailored against the target App workload. This is essentially a __Machine Learning__ problem, where Optimal Column Layout explored for in-place updates (binary linear optimization).

### Garbage collection (GC) / Compaction

GC/compaction are common in append-only or LSM-tree systems and quite bandwidth consuming. Update in-place systems can also use compaction to generate read-optimized layout, and need GC if some new values are temporarily written out-of-place. I choose to mix the notation of GC/compaction because both reclaim stale/deleted values. Compaction can replace GC in LSM-tree, and GC can go without compaction if index/bloomfilter/versioning tell which key is stale.

Typical design __goals__ for effective GC/compaction are below. They map to the goals of data layout.

  * Be timely enough to reduce __read amplification__ incurred on user reads.

  * Be timely enough to reduce __space amplification__.

  * Pay less for __write amplification__ either inline in write path or offline in background jobs.

  * Arrange __sequential reads__ and __sequential writes__ when possible.

  * Spend reasonable amount of __CPU/memory/disk__. Less compete with user traffic or stall them.

The design space of GC/compaction consists of a series of "knobs" choosing when and how to run

  * __Size granularity__. How big is the data unit selected for GC/compaction? It can be an individual chunk, a group of chunks, or compact with all chunks in a LSM-tree sorted run or level. A chunk can either be configured small or large. Essentially, enforcing sort order on a wider range implies correspondingly larger compaction granularity, which benefits reads but is more costly to maintain. A large granularity costs less tracking metadata but incurs more rewrite on unnecessary data.

  * __Selecting candidates__. Which chunk to GC/compact with which other chunks. A GC/compaction run is more efficient if it removes the most stale values, or when chunks having more possible overlapping. A new chunk can also be pushed off to accumulate more stale values. Proper indexing and statistics tracking can be spent here. Selecting best candidates optimizes GC/compaction.

  * __When to trigger__. When to start run GC/compaction? It can be when storage space is filled up, certain LSM-tree level reached max size, a chunk accumulated enough old stale keys, periodical timer triggered, recent read/write cost reached alarm or stalled due to pending work, or user traffic is low enough. They target to proactively maintain system properties while minimally impact user activity.

  * __Where to run__. Traditionally GC/compaction need to run in local node to save network/disk transfer. However in shared storage, chunks can be loaded by other nodes to scaleout the computation. They can also have extra replicated copies to balance reads, or smart SSDs to compute in hardware. More, GC/compaction can store data in cloud storage (e.g. S3), disaggregate storage components (e.g. Snowflake), and offload computation to cloud (e.g. Remote Compaction).

Base on data unit for classification (mentioned previously), e.g. generation, temperature, workload streams, different GC/compaction strategies (the above) can be applied.

  * __Generation__. I.e. the level 0, 1, 2, .. N in LSM-tree or RocksDB. Each level is typically configured with different max sizes, chunk size, GC/compaction frequency. They can also use different tiering vs leveling strategy. An example is Lazy Leveling in Dostoevsky. Roughly, lower levels incurs more write amplification because they compact more frequently, while higher levels incur more read amplification because of scanning large chunks.

  * __Temperature tiering__. It's beneficial to delay hot data, keep them in memory, which then accumulate more stale values to GC/compact in one run. Cold data should be separated from hot data, to avoid polluting and forced to rewrite altogether. GC/compaction can run more infrequently on cold data because they have less activity. An example is [TRIAD][341].

  * __Workload streams__. It groups data which have similar temperature hot/cold level. The correlated data with similar lifecycle are more likely to be deleted/updated together, so to be reclaimed in one GC/compaction run. The example is files in Google Drive, where a file is deleted as a whole, but mixing blocks from different files in one chunk results in fragmented lifecycle.

HyPer [Scalable MVCC GC paper][342] also gives another similar categorization of GC designs (for DB MVCC versions): Tracking Level, Trigger Frequency, Version Storage, Identification of obsolete versions, Removal of garbage versions.

![HyPer paper GC categorization](/images/arch-design-hyper-gc-categorize.png "HyPer paper GC categorization")

### Compression

Columnar format organizes data in compressed way. The compression algorithms yet allow reading records directly without decompression. The below [compression algorithm selection taxonomy][343] not only reflects common properties in data, but also data organization in compression to query efficiently.

![What compression schema to use in columnar format](/images/arch-design-columnar-compress-taxonomy.png "What compression schema to use in columnar format")

The above is categorized as "Columnar compression". There are more compression algorithm families available for storage systems. They can be categorized as below

  * __Block based compression__. The classic daily used compression algorithm. [LZ77][344] is the heart of most of them: ZIP, LZ4, LZ* family, GZIP, DEFLAT, 7-ZIP, RAR, Zstd. LZ77 does dedup, where text tokens pointing to each other virtually composes a dictionary. LZ77 is usually used with an [Anti-entropy stage][345] to further shorten bit representation, see "Anti-entropy compression".

  * __Explicit dictionary based compression__. DB compressing string values can specialize to use algorithms like [FSST string symbol table][346], whose core is a lookup dictionary. Zstd also provides a [Zstd dictionary mode][347], where a pre-trained dictionary can be supplied to compress small documents.

  * __Succinct data structures__. We mentioned it before. Besides, [LZ-End][348] is an interesting algorithm recognized in research. It slightly modifies LZ77 to support random access without block decompression, but yet needs a few extra lookups with address jumps.

  * __Columnar compression__. Columnar DB uses it to compress columns. These family of algorithms are shown in the above taxonomy picture. Such compression assumes column data shares similarity. They typically support index point lookup, scan, query filtering, without decompression (Late Materialization).

  * __Anti-entropy compression__. As used along with LZ77 family, the algorithms select bit representation for entries according to their frequency, so that the total bit length is shorter. E.g. Zstd uses LZ77 + [FiniteStateEntropy][349].
