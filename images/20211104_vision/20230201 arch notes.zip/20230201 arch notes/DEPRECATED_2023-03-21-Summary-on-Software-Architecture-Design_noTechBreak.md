
The article summarizes my experiences on software architecture. Architecture design is essentially driven by __philosophies__ as the generator engine that governs all knowledge. From the __organization view__, we can find why and how architecture design process and skills are required that way. Common __methodologies__ and __principles__, viewed from the philosophies, provide guidance to carry out architecture design with quality. An architect needs an armory of techniques for different __system properties__. I categorized __Reference architectures__ in each distributed storage area, summarize __architecture design patterns__ from them, and connect them into __technology design spaces__.

__Table of Contents__

* [Software architecture - A philosophy perspective](.)
  * [Reality, language, and human mind](.)
  * [About software architecture](.)
  * [Side notes: Explaining with examples](.)
* [Why need software architecture](.)
  * [Technology aspects](.)
  * [Capturing the big](.)
  * [Process & Organization](.)
* [Different architecture organization styles](.)
  * [Architect the tech lead](.)
  * [Architecture BU](.)
  * [Peer-to-peer architect](.)
  * [System analyst](.)
  * [Borrow and improve](.)
* [Key processes in software architecture](.)
  * [Knowledge and skills](.)
  * [Carry out the steps](.)
  * [Designed to evolve](.)
  * [Driving the project](.)
* [Key methodologies in software architecture](.)
  * [Managing the complexity](.)
  * [Levels of architecture design](.)
  * [Views of architecture design](.)
* [Common architecture styles](.)
  * [More recent architectures](.)
* [General architecture principles](.)
  * [Architecture level](.)
  * [Component level](.)
  * [Class level](.)
  * [About OO design and Simple & direct](.)
  * [About optimized algorithms and robust design](.)
  * [About analytical skills in designing](.)
* [Technology design spaces - Overview](.)
  * [Sources to learn from](.)
  * [Reference architectures in storage areas](.)
    * [Cache](.)
    * [(Distributed) Filesystem](.)
    * [Object/Block Storage](.)
    * [Data deduplication](.)
    * [Archival storage](.)
    * [OLTP/OLAP database](.)
    * [In-memory database](.)
    * [NoSQL database](.)
    * [Graph database](.)
    * [Datalake](.)
    * [Stream processing](.)
    * [Persistent memory](.)
    * [Cloud native](.)
    * [Secondary Indexing](.)
    * [Content distribution network (CDN)](.)
  * [Storage components breakdown](.)
* [Technology design spaces - Breakdown](.)
  * [Metadata](.)
    * [Metadata size](.)
    * [Metadata scaleout](.)
    * [Metadata storage](.)
    * [Metadata offloading](.)
    * [Metadata consistency](.)
  * [Consistency](.)
    * [Single node level consistency](.)
    * [Datacenter level consistency](.)
    * [Geo-regional level consistency](.)
  * [Write path](.)
    * [Append-only vs update in-place](.)
    * [Co-updating neighbor components](.)
    * [Write to different storage media](.)
    * [Tiering between different storage media](.)
    * [Write & read paths coalescing](.)
    * [Offloading](.)
  * [Data organization](.)
    * [Durability tier](.)
    * [Data layout for query tier](.)
    * [Garbage collection (GC) / Compaction](.)
    * [Compression](.)
  * [Data indexing](.)
    * [Data index properties](.)
    * [Popular data indexes](.)
    * [Data indexes in distributed storage](.)
    * [Succinct data structures](.)
  * [Data caching](.)
    * [Memory caching](.)
    * [SSD caching](.)
    * [Metadata caching](.)
  * [Data partitioning & placement](.)
    * [Common techniques](.)
  * [Data integrity](.)
    * [Methodologies](.)
    * [High availability](.)
    * [Durability](.)
  * [Resource scheduling](.)
    * [Design dimensions](.)
  * [Performance](.)
    * [Concurrency & parallelism](.)
    * [CPU-cache and in-memory](.)
    * [Scaleout storage](.)
  * [Networking](.)
    * [Networking architecture](.)
    * [Load balancers](.)
    * [Congestion control](.)
    * [Networking stack](.)
    * [Application layer](.)
  * [More topics](.)
* [Conclusion](.)

![Distributed storage landscape overview](/images/arch-design-landscape-overview.png "Distributed storage landscape overview")


# Software architecture - A philosophy perspective

Software architecture is a modeling of the reality world, a language, and a human mind creation to assist human mind. Language is an interesting topic. The three together are deeply interconnected, pointing why, what and how to handle software architecture. The next and following chapters tell about knowledge in software architecture. But this first chapter tells about the engine that generates the knowledge.

![Cutting the apple and desk](/images/arch-design-apple-desk-cut.png "Cutting the apple and desk")

// TODO Insert sub article


# Why need software architecture

There are various aspects why software architecture is necessary, besides technology. These aspects together define what software architecture should be, and correspondingly the methodology and knowledge landscape developed.

## Technology aspects

  * __Handling the complexity__. Software design are separated into architecture level, component level, and class level. Each level popularize with own techniques: 4+1 view, design patterns, refactoring. Any challenge can be solved by adding one layer of abstraction.

  * __Decide key technology stack__. Internet companies commonly build services atop opensource stacks across different domains, e.g. database, caching, service mesh. Which stack to use affects architecture, and are often evaluated with technology goals and organization resources.

  * __Cost of faults__. The cost of correcting a fault at early design is way lower than at full-fledged implementation, especially the architecture level faults that need to restructure component interconnects.

## Capturing the big

  * __Non-functional requirements__. Typically, availability, scalability, consistency, performance, security, [COGS][2]. More importantly, possible worst cases, how to degrade, critical paths. Also, testability, usability, quality, extensibility, delivery & rollout. They are not explicit customer functional needs, but usually more important, and touches wide scope of components to finally implement.

  * __Capturing the changing and non-changing__. Architecture design identifies what changes quickly, and what can be stable. The former is usually localized and encapsulated with abstraction, or outsourced to plugin. The later is designed with an ask "can this architecture run 1/3/5 years without overhaul", which usually reflects to components and interconnections.

  * __Issue, strategy, and decision__. Architecture is where to capture key issues in system, technology, organization. Strategies are developed to cope with them. And a explicit track of design decisions are documented.

  * __Clarify the fuzziness__. At architecture step, not uncommonly the customer requirements are unclear, problems are complex and clouded, future is unstable, and system scope is unknown. The architect role analyzes, defines, designs solution/alternatives, and builds consensus across teams.

  * __Capture the big__. Architect role needs to define what system properties must be grasped in tight control throughout project lifecycle. They map to the __project goals__ of success and key safety criteria. More importantly, architect role needs to decide what to give up, which may not be as easy as it looks, and reach consensus across teams.

## Process & Organization

  * __Project management__. Architecture step is usually where the cost effort, touching scope, delivery artifact, development model; and resource, schedule, quality can be determined and evaluated. It is also where to closely work with customers to lock down requirements. Project management usually works with the architect role.

  * __Review and evaluation__. Architecture step is usually where the key designs are reviewed; the key benefit, cost, risk are evaluated; throughput capacity breakdown are verified; and all user scenarios and system scenarios are ensured to be addressed. This usually involves stakeholders from different backgrounds and engage with senior management.

  * __Cross team collaboration__. Architecture touches various external systems and stakeholders. It is when to __break barrier and build consensus__ cross teams or BUs. It is when to ensure support and get response from key stakeholders. It is where to drive collaboration. Unlike technology which only involves oneself, driving collaboration can be a larger challenge.

  * __Tracks and lanes__. The architect role usually builds the framework, and then the many team members quickly contribute code under given components. It sets tracks and lanes where the code can grow and where not, i.e. the basis of intra-team collaboration. Future, the tracks and lanes are visions for future roadmap, and standards for team to daily co-work.

![Architect role](/images/arch-design-architect-role.png "Architect role")


# Different architecture organization styles

What an architect role does and means in real world industry are somehow puzzled. From my experience, this is due to architecture step is organized differently at different companies. At some, architect is the next job position of every software developer. At some others, I didn't even see an explicit architect job position.

## Architect the tech lead

Usually seen at Internet companies. The architect role is taken by a senior guy in the team, who masters technology stacks and design principles. The architect makes decision on which technology stack to use, and builds the framework for the following team members to fill concrete code. The architect role is in high demand, because Internet companies quickly spin up App after App, each needs its architect, while the underlying opensource infrastructure is relatively stable. Both the business value and technology stack win traction. The API richness in upper App level implies more products and components to host new architects, while infra level generally has simpler API and honors vertical depth.

## Architecture BU

BU - business unit, i.e. department. Usually seen at Telecom companies. Architects work with architects, software developers work with software developers; they reside at different BUs. The architecture results are handed off in middle, following a waterfall / CMMI model. The architecture designs on more stable, even standardized requirements, with very strict verification, and delivers completeness of documentation. Strong process, and expect more meetings bouncing across BUs. Employees tend to be separated into decision making layer and execution layer, where the later one expects long work, limited growth, and early retire.

## Peer-to-peer architect

Usually seen at teams building dedicated technology. Unlike Internet companies spinning up Apps horizontally atop many different technologies, such team vertically focuses on one, e.g. to build a database, a cloud storage, an infrastructure component, i.e. 2C (former) vs 2B (later) culture. No dedicated architect job position, but shared by everyone. Anyone can start a design proposal (incremental, new component, even new service). The design undergoes a few rounds of review from a group of senior guys, not fixed but selected by relevance and interest. Anyone can contribute to the design, and can join freely to set off with project development. Quite organic. Technology is the key traction here, where new architecture can be invented for it (e.g. new NVM media to storage design).

## System analyst

Usually seen at companies selling ERP (Enterprise resource planning), or outsourcing. The systems are heavily involved into customer side domain knowledge. And the domain knowledge is invalidated when selling to another customer from a different domain. Because of new background each time, comprehensive requirement analysis and architecture procedures are developed. When domain can be reused, domain experts are valued, where __knowledge and experience themselves are good designs__. Domain knowledge can win more traction than technology, where the later one more leans to stability and cost management.

## Borrow and improve

Usually seen at follower companies. If not edge cutting into no man's land, __reference architecture__ (top product's architecture) can usually be found to borrow from, to customize and improve. This is also benefited by the wide variety of opensource. Reference architecture, standing on the shoulder of giants, are widely used in software architecture processes, e.g. comparing peer works, which is another example of knowledge and experience themselves are good designs. Market technology investigation survey are high demanding skills.


# Key processes in software architecture

How to successfully drive the software architecture process? It involves various collaboration with upstream and downstream, identify the scope, and break barrier and build consensus. Problem analysis and implementation deployment are connected with data driven evaluation, to compose the continuous feedback loop to drive future evolution.

## Knowledge and skills

As preparation, architecture design requires below knowledge and skills

  * Downstream, __understand your customer__. The customer here also includes downstream systems that consume yours. Know customer to capture key aspects to prioritize in architecture, and more importantly what to de-prioritize (E.g. favor latency over cost? Is consistency and HA really needed?). It helps identify the risks (E.g. festival burst usage, backup traffic pattern). Besides, well defining customer space reveals future directions the architecture can evolve.

  * Upstream, __understand what your system is built atop__. A web App can be built atop a range of server engines, service mesh, database, caching, monitoring, analytics, etc. Mastering the technology stacks is necessary for designing architecture that works with the practical world, and for choosing correct technology stacks that suit project goals and team capabilities.

  * Externally, __understand the prior of art__. To design a good system, you need to know your position in the industry. Reference architecture can be discovered and borrowed from. Existing technology and experience should be leveraged. E.g. given the richness of opensource databases, designing a new data storage is even a selection and cropping of existing techniques. Participating in meetups helps exchange industry status, and to ensure your design is not drifting away into a pitfall.

  * Internally, __understand your existing systems__. Understand the existing system to make designs that actually work, and to correctly prioritize what helps a lot and what helps little. Learn from past design history, experience, and pitfalls, to reuse and go the right path.

  * Organizationally, __broaden your scope__. Architecture design involves interacting with multiple external systems and stakeholders. Be sure to broaden your scope and get familiar with them. Communicate with more people. Solid soft skills are needed for cross team / BU collaboration, to break barrier and build consensus, and to convey with action-oriented points, concise, big picture integrated with detailed analysis.

## Carry out the steps

I lean more to peer-to-peer architect style mentioned above. Many can be sensed from [GXSC's answer][3]. At each step, be sure to engage __talk with different persons__ which significantly improves design robustness. Rather than the design results, it's problem analysis and alternative trade-off analysis that weight most.

  * Firstly, __problem analysis__. Design proposal starts from innovation. Finding the correct problem to solve is half-way to success. The cost and benefit should be translated to the final __market money__ (Anti-example: we should do it because the technology is remarkable. Good-example: we adopt this design because it maps to $$$ annual COGS saving). The __problem scope__ should be complete, e.g. don't miss out upgrading and rollout scenarios, ripple effect to surrounding systems, or exotic traffic patterns that are rare but do happen in large scale deployment. __Risk__ should be identified; internally from technology stacks, externally from cross teams, market, and organization. __The key of management is to peace out risks__, same with managing the design.

  * One important aspect from problem analysis is __prioritization__. Architecture design, even the final system, cannot address each problem. You must decide __what to discard__, what to suppress, what to push down to lower level design, what choices to make now and what to defer, what to push into abstraction, what to rely on external systems, what to push off as future optimization; and to decide what are the __critical properties__ you must grasp tightly throughout the project lifetime and monitor end-to-end. I.e. __the other key of management is to identify the critical path__. Prioritization are usually determined by organization goals, key project benefits and costs, and the art to coordinate across teams.

  * Next, __find alternatives__. To solve one problem, at least two proposals should be developed. __Trade-off analysis__ is carried out to evaluate the Pros and Cons. Usually, Pros yet have special cases to make it worse, and Cons yet have compensations to make it not bad. The discussion is carried out across team members, up/downstream teams, stakeholders, which may in turn discover new alternatives. The process is __iterative__, where the effort is non-trivial, multiplied, because it's not developing one but a ripple tree of solutions. Eventually you explored the completeness of __design space__ and __technology space__, and reached consensus across team. Choosing the final alternative can be carried out with team voting, or with a [score matrix][4] to compare.

  * __Review__ with more people. Firstly, find one or two local nearby guys for __early review__, to build a more solid proposal. Next, find __senior and experienced__ guys to review, to make sure no scenarios are missing, all can be reused are reused, and the solution is using the best approach. Then, involve key __upstream__ guys, to ensure required features, load level, and hidden constraints, are actually supported; and to ensure their own feature rollout won't impact yours. Involve key __downstream__ guys, to ensure the new system addresses what they actually want. It's important to involve key __stakeholders__ early; make sure you gain support from organization, you deliver visibility, and you align with high level prioritization.

  * Then __evaluation__ for the architecture design. Make sure the problem analysis, every customer __scenario__ and system scenario, and project goals, are well addressed. Make sure __non-functional__ requirements are addressed. Make sure the key project __benefit and cost__ are verified in a __data driven approach__, with actual production numbers as input, using a prototype, simulation tools, or math formulas to model. Make sure the system can support required __load level__, by breaking down throughput capacity into each component. Make sure the system handles the __worst case__ and supports graceful throttling and downgrade. Make sure the __logic has completeness__; e.g. when you handle a Yes path, you must also address No path; e.g. you start a workflow, you must also handle how it ends, go back, interleaved, looped. Make sure __development and deliver__ are addressed, e.g. how to infra is to support multi-team development, the branching policy, component start/online/maintenance/retire strategies, CI/CD and rollout safety. Also, make sure __hidden assumptions__ and constraints are explicitly pointed out and addressed.

  * Finally, it's the __documentation__. On practice, it involves a short "__one pager__" document (actually can be < 20 pages), and slides for quick presentation, and spreadsheets for data evaluation. Nowadays culture lean more to lightweight document, central truth in codebase, and prioritize agile and peer-to-peer communication. Problem analysis and alternative trade-off analysis usually weight more in document than the design itself, where __defining the problem space__ is a key ability. Architecture design part usually includes key data structure, components, state machines, workflows, interfaces, key scenario walkthrough, and several detailed issue discussion. Importantly, the document should track the change history of design decision, i.e. how they reach today, and more specifically the __Issue, Strategy, Design Decision__ chain.

  * Another output of architecture design are __interfaces__. Interface design does have principles (see later). They are the tracks and lanes where following development start. They reveal how components are cut and interactions to happen. They also propagate expectations of your system to external systems, such as how they should co-work, what should be passed.

## Designed to evolve

__Architecture is designed to evolve__, and prioritized to make it evolve faster. [Ele.me Payment System][5] is a good example in a 5 year scope. Competency of nowadays software depend on the velocity it evolves, rather than a static function set.

  * __[Simple is beauty][6]__. Initial architecture usually only address key requirements. What changes and not changes in several year's scope are identified and addressed with abstraction. __[MVP][7]__ is a viable first deployment, after which it yet becomes challenging how to "replace wheels on a racing van".

  * __Highway is important__. Functionalities in software resembles to tall buildings in a city, where highways and roads are key how they build fast. These architecture aspects are less visible, usually under prioritized, but are life critical. Inside the system, they can be the debugability, logging, visibility and monitoring. Have they defined quality standards? Do monitoring have more 9s when the system is to be reliable? From infrastructure, they can be the tooling, platform, config system, fast rollout, data obtaining convenience and analytics, scripting. At organization level, they can be the team process and culture to facilitate agile moves. Externally, they can be the ecosystem and plugin extensibility. E.g. [Chrome Apps][8] with plugins designed as first-class. E.g. [Minecraft][9] published tools to build 3rd-party mods. E.g. [Opensource Envoy][10] designs for community engagement from day 1.

  * Build the __feedback loop__. Eventually after project rollout and deploy, you should be able to collect data and evaluate the actual benefit and costs. New gaps can be found, and yet facilitate a new round of design and improve. How to construct such feedback loop with __data driven__ should be taken into consideration of architecture design.

## Driving the project

The last point is about __driving the project__. The architect role is usually accompanied with ownership, and be responsible to the progress and final results. Driving goes not only the architecture step, but also along with entire project execution. Many can be sensed from [道延架构 article][11].

  * There can be timeline schedule issues, new technical __challenges__, new blockers, more necessary communication with up/downstream; previous assumptions may not hold, circumstances can be __changed__, new risks will need engage; there can be many people joining and many needs to coordinate, and many items to follow up.

  * Besides the knowledge and communication skills, driving involves the __long time perseverance__, attention, and care. The ability to find real problems, to prioritize and leverage resources, to push, the experiences, and the skillset of __project management__, are valued. To drive also means to __motivate__ team members to join and innovate. The design becomes more robust, completed, improved, with more people help; and with people from __different perspectives__ to look.

  * More, __driving is a mindset__. You are not who asks questions, people ask questions to you, and you are the final barrier to decide whether problem is solvable or not. The most difficult problems naturally routes to you. If solving the problem needs resource, you make the plan and lobby for the support. You make prioritization, you define, and you eat the dogfood. The team follow you to success (if not otherwise).

![Architecture design feedback loop](/images/arch-design-process-loop.png "Architecture design feedback loop")


# Key methodologies in software architecture

Software architecture is a large topic that I didn't find a canonical structure. I divide it into process (above), methodologies (this chapter), principles, system properties and design patterns, technology design spaces. The article is organized as it.

  * __Process__. Already covered in the above chapters. It involves how real world organizations carry out architecture design, and conceptually what should be done for it.

  * __Methodologies__. The analysis method, concept framework, and general structure, to carry out architecture design. They also interleave with principles and philosophies. Methodologies change with culture trends, organization styles, and technology paradigms. But throughout the years, there are still valuable points left.

  * __Principles__. Architecture level, component level, class level each has many principles, common or specific. Essentially they are designed to reduce mind burden, by letting the code space to mimic how human mind is organized.

  * __System properties and design patterns__. Distributed systems have non-functional properties like scaleout, consistency, HA (high availability). Various architectural design patterns are developed to address each. They are the reusable knowledge and domain language. Best practices can be learned from reference architecture, more market players, and historical systems; where __architecture archaeology__ systematically surveys through the past history of systems.

  * __Technology design spaces__. A technology, e.g. database, can evolve into different architectures after adapting to respective workload and scenarios, e.g. OLAP vs OLTP, in-memory of on disk. Exploring the choices and architectures, plotting them on the landscape, reveals the design space. With this global picture in mind, the design space landscape greatly helps navigating the new round of architecture design.

## Managing the complexity

The first and ever biggest topic in architecture design (or software design) is to __handle complexity__. The essence is to __let the code space mimic human mind__, i.e. how the human language is organized (if you have read the philosophy chapter). Human language is itself the best model of the complex world, which is a "design" polished by human history, and yet shared by everyone. Domain knowledge is thus helpful, as it is the language itself. When code space is close to the language space (or use a good metaphor), it naturally saves everyone's mind burden.

// TODO Insert sub article

## Levels of architecture design

Software design is complex. To manage the complexity, I break it into different __levels and views__. Typical levels are: architecture level, component level, and class level. The abstraction level goes from high to low, scope from big to small, and uncertainty from fuzzy to clear. Each level yet has its own methodologies. Levels also map to first-and-next steps, which in practice can be simplified or mixed, to lean more to the real world bottleneck.

// TODO Insert sub article



# Common architecture styles

This is the old topic, a generic design pattern on the scale of architecture. New recent technologies bring more paradigms, but the essence can be tracked back. Company-wide the architecture may eventually evolve to reflect the organization's communication structure ([Conway's Law][13]), besides the technical aspects.

  * __Layered architecture__. Now every architecture cannot totally discard this.

  * __Repository/blackboard architecture__. All components are built around the central database (the "Repository/blackboard"). They use pull model or get pushed by updates.

  * __Main program and subroutines__. Typical C-lang program architecture, __procedure-oriented__ programming, and can usually be seen at simple tools. The opposite side is object-oriented programming.

  * __Dataflow architecture__. Still procedure-oriented programming, it can typically be represented by dataflow diagram. The architecture is useful for data processing, especially chips/FPGA, and image processing. __Pipeline and filters__ are another architecture accompanied with.

  * __MVC (Model-view-controller)__. The fundamental architecture to build UI. It separates data, representation, and business logic. It gets richer variants in richer client UI, e.g. React.

  * __Client server__. The style that old fashion client device connects to server. Nowadays it's usually Web, REST API, or SOA instead. But the architecture is still useful in IoT, or as a host agent to report status / receive command to central server, or as a rich client lib to speedup system interactions.

  * __The mediator__. Suppose N components are connecting to M components, instead of N * M connections, a "mediator" component is introduced in middle to turn it to N + M connections.

  * __Event sourcing__. User sends command, and every system change is driven by an event. System stores the chain of events as the central truth. Realtime states can be derived from event replay, and speedup by checkpoints. The system naturally supports auditing, and is append-only and immutable.

  * __Functional programming__. This is more an ideal methodology rather than a concrete architecture. Variables are immutable; system states are instead defined by a chain of function calls. I.e. it's defined by math formula, or a bit like event sourcing. Functions are thus the first-class citizens.

![Common architecture styles](/images/arch-design-common-styles.png "Common architecture styles")

## More recent architectures

More recent architectures below. You can see architectures vary on: How to cut boundaries, e.g. fine-grain levels, offloading to cloud. Natural structures, e.g. layered, event & streaming, business logic, model-view UI. The gravity of complexity, e.g. complex structures, performance, consistency, managing data, security & auditing, loose communication channels.

  * __Microservice__. Complex systems are broken into microservices interacting with REST APIs. Typical examples are __Kubernetes and Service Mesh__. You yet need an even more complex container infrastructure to run microservices: [SDN][39] controller and agents for virtual networking, HA load balancer to distribute traffic, circuit breaker to protect from traffic surge, service registry to manage REST endpoints, Paxos quorum to manage locking and consistent metadata, persistent storage to provide disk volumes and database services, ... Below is [Netflix microservice architecture][40] for example.

![Netflix microservice architecture](/images/arch-design-netflix-microservice.png "Netflix microservice architecture")

  * __Stream processing__. Upstream and downstream systems, across company-wide, are connected via messaging queue, or low latency streaming platforms. Nowadays enterprises are moving from __Lambda architecture__ (realtime approximate streaming and delayed accurate batching are separated) to __[Kappa architecture][41]__ (combine both into streaming, with consistent transaction). A more complex system can comprise [online, nearline, offline][42] parts, as in below picture.

![Netflix online/nearline/offline architecture](/images/arch-design-netflix-nearline.png "Netflix online/nearline/offline architecture")

  * __Cloud native__. The system is designed to run exclusively on cloud infrastructure (but to be hybrid cloud). The typical example is [Snowflake][43] database. Key designs are: 1) Disk file persistence are offloaded to __S3__. 2) Memory caching, query processing, storage are __disaggregated__ and can independently scaleout and be elastic for traffic surge. 3) Read path and write path can separately scale, where typical users generate write contents in steady throughput and read traffic in spikes. 4) Different tiers of resources, since fully disaggregated, can accurately charge billing for how much a customer actually uses.  __Serverless__ is another topic, where all the heavy parts like database and programming runtime are shifted to cloud. Programmers focus on writing functions to do what business values, lightweighted and elastic to traffic. Below is [Snowflake architecture][44] for example.

![Snowflake architecture](/images/arch-design-snowflake.png "Snowflake architecture")

  * __[DDD onion architecture][45]__. The onion (or call it hexagon) architecture comes to shape in the context of DDD. Domain model is the central part. The next layer outside are applications. The outer layer are adapters that connects to external systems. Onion architecture is neutral to the actual technical architecture being implemented. Domain models can also be connected to test cases to easily validate business logic (rather than the verbosity of preparing testbed with fake data in databases, fake REST interfaces, etc).

![DDD onion architecture](/images/arch-design-DDD-onion.png "DDD onion architecture")

  * __[React-Redux][46]__. The architecture is a more advanced version of MVC. With data pulled from server-side, Javascripts at client-side runs MVC itself. Views are constructed by templates + input properties. User actions generate events, which trigger actions, e.g. call services. New updates are sent to reducer, which then map to store. Container uses selectors to fetch states from store, map them to properties, and then finally render the new view. The architecture is also frequently accompanied with Electron and NodeJS to develop rich client Apps with web technologies.

![React-Redux architecture](/images/arch-design-react-redux.png "React-Redux architecture")


# General architecture principles

## Architecture level

Most principles are already reflected in the above sections. At __architecture level__, the most mentioned principles are below three ([Architecture 3 principles][6])

  * __Keep it simple__. There are enough complexity; simple is precious. Related to [KISS][12].

  * __Suitable__. Enough for the need, is better than "industrial leading". An architecture should be suitable, to steer it with your concrete requirement and team resources, rather than to vainly pursuit new technologies. Be frugal. The benefit of a design should be mapped to financial cost to evaluate.

  * __Designed for evolving__. Business needs are changing. Traffic scale are increasing. Team members may come and go. Technologies are updating. An architecture should be designed evolvable. The architecture process (and development) should be carried out with a [growth mindset][47]. An example is [Ele.me Payment System][5], which is quite common for Internet companies.

## Component level

More principles come to __component level__ design. [CoolShell design principles][48] is good to list all of them. Below are what I think most useful

  * __Keep It Simple__, Stupid (KISS), You Ain't Gonna Need It (YAGNI), Don't Repeat Yourself (DRY), Principle of Least Knowledge, Separation of Concerns (SoC): That said, make everything simple. If you cannot, divide and conquer.

  * Object-oriented __S.O.L.I.D__. Single Responsibility Principle (SRP), Open/Closed Principle (OCP), Liskov substitution principle (LSP), Interface Segregation Principle (ISP), Dependency Inversion Principle (DIP). Note that though OO principles try to isolate concerns and make changes local, refactoring and maintaining the system in well such state however involves global knowledge of global dependency.

  * __Idempotent__. Not only API, the system operation should be idempotent when replayed, or reentrantable. A distributed system can commonly lost message and do retry. Idempotent examples can be doing sync (rather than update, sync a command to node, which is consistent after node fail-recovers and re-executes); propagating info in __eventual consistency and in one direction__; re-executing actions without side effect; __goal states__ commonly used in deployment and config change.

  * __Orthogonality__. Component behavior is totally isolated from each other. They don't assume any hidden behaviors from another. They work, no matter what others output. Not only the code path, also the development process can be orthogonal, with a wise cut of components. Orthogonality greatly saves the mind burden, communication cost, and ripple impact of changes.

  * __Hollywood Principle__, don't call us, we'll call you. Component doesn't `new` components. It's however the Container who manages Component creation and initialization. It's inversion of control, or dependency injection. Examples are [Spring DOI][49], [AspectJ AOP][50]. Dependency should be towards the more stable direction.

  * __Convention over Configuration（CoC)__. Properly set default values, save the caller's effort to always pass in comprehensive configurations. This principle is useful to design opensource libs, e.g. Rails. However, large scale production services may require explicit and tight control on configuration, and the ability to dynamic change. [Microsoft SDP][51] is an example.

  * __Design by Contract (DbC)__. A component / class should work by its "naming", i.e. contract, rather than implementation. A caller should call a component by its "naming", instead of the effort to look into its internals. The principle maps to objects should work objects at the same abstraction level, and to respect responsibilities.

  * __Acyclic Dependencies Principle (ADP)__. Try not to create a cyclic dependency in your components. Ideally, yes. In fact, cyclic dependency still happens, when multiple sub-systems are broker-ed by a message queue. Essentially, components need interaction, just like people.

## Class level

Coming to __class level__ or lower component level, the principles can be found from __[Coding Styles][19]__, __[Code Refactoring][20]__, __[Code Complete][21]__; this article won't cover.  However, it's interesting to evaluate if a piece of code is __good design__, which people frequently argue for long time without an agreement. In fact, several distinct design philosophies all apply, which can be found from diverged opensource codebases and programming language designs. To end the arguing, practical principles are

  * Compare __concrete benefits/costs__ to team and daily work, rather than design philosophies.

  * Build the compare on __concrete real usecases__, rather than blindly forecasting future for design extensibility.

## About OO design and Simple & direct

Continued from the above discussion about evaluating a piece of code is good design. The key concern should be whether it __saves mind burden__ across team. There are generally two paradigms: OO design and Simple & direct. They work in different ways.

// TODO Insert sub article

## About optimized algorithms and robust design

A similar discussion like "OO design vs Simple & direct" is whether to use the fast low overhead algorithm or a simple & direct solution.

// TODO Insert sub article

## About analytical skills in designing

Proposing a reasonable design solution and the right decision making require analytical skills. Some can be learned from the [Consultant area][480]. They help dissect complex problems and navigate through seemingly endless arguments.

// TODO Insert sub article


# Technology design spaces - Overview

Software architecture has common __system properties__, e.g. [CAP][52]. To achieve them, different techniques are invented and evolve into more general __architecture design patterns__. Plotting them on the map of various driving factors, they reveal the landscape of __technology design space__, that we explore and navigate for building new systems. I'll focus on __distributed storage__.

## Sources to learn from

Articles, books, and courses teach design patterns. Recognized opensource and industry systems become the __Reference architectures__. Related works section in generous papers are useful. Good papers and surveys can enlighten the technology landscape.

// TODO Insert sub article

## Reference architectures in storage areas

知名的开源和行业系统（industry systems）变成 __参考架构__（reference architectures），可以用来学习流行的技术或设计模式。它们是各领域的代表作，技术和优化的集成者。分解参考架构，重组技术零件，绘制设计空间。下文列出了我能很快记起的参考架构（可能 __不完整__ ）。它们可以通过搜索流行产品、比较商业备选方案、或从高引用论文中找到。

// TODO Insert sub article

## Storage components breakdown

To plot the architecture design space for distributed storage systems, we divide it by three different dimensions. They map to static/runtime views and non-functional goals of the architecture. Common components can be extracted from sources like section [Reference architectures section](.). They may overlap, while I strive to separate them concisely and clearly.

__Divide by storage areas__

  * Cache
  * Filesystem
    * Distributed filesystem
  * Object/Block Storage
  * Data deduplication
  * Archival storage
  * OLTP/OLAP database
    * Shared logging
  * In-memory database
    * Manycore
  * NoSQL database
  * Graph database
  * Datalake
  * Stream processing
  * Persistent memory
  * Cloud native
    * Cloud scheduling
    * Geo Migration
  * Secondary indexing
  * Query processing

__Divide by static components__

  * Metadata nodes
  * Data nodes
  * Indexing
  * Logging & journaling
  * Transaction control
  * Allocator
  * Data layout
  * Data compression
  * Data deduplication
  * Caching layer
  * Cold/hot tiering
  * Client
  * Storage media
  * Networking & messaging
  * Backup & disaster recovery
  * Upgrade/deployment and restart
  * Monitoring & alerting
  * Configuration management

__Divide by runtime workflows__

  * Read path
  * Write path - append/overwrite
  * Load balancing
  * Data replication/repair/migration
  * GC/compaction
  * Data scrubbing
  * Failure recovery
  * Node membership & failure detection
  * Background jobs
  * Clock synchronization
  * Resource scheduling & quota/throttling
  * Overload control
  * Offloading

__Divide by system properties__

  * Traffic pattern, query model
  * Data partitioning & placement
  * Consistency
  * Transaction & ACID
  * Scaleout
  * Scale-up
  * High availability
  * Data durability
  * Data integrity
  * Read/write amplification
  * Space amplification
  * Concurrency & parallelism
  * Throughput & latency
  * Cross geo-regions
  * Operational ease
  * Interoperability

![Distributed storage system overview](/images/arch-design-storage-overview.png "Distributed storage system overview")

# Technology design spaces - Breakdown

The following sections talk about each technology design space. They root in "Reference architectures" listed above, and cover areas in "Storage components breakdown". Unlike breakdowns, techniques and design patterns usually interleave multiple components and require co-design. __Architecture design patterns__, also covered below, map to certain __techniques__ to achieve desired __system properties__. When connected the dots, they expand to a consecutive __design space__ that enlightens more choices.

## Metadata

Key problems related to metadata are the size of metadata, how to scaleout, where to store, and consistency. Metadata size is closely related to data partitioning and placement. Essentially, the size of metadata is determined by __tracking granularity__ and __degree of freedom__ the per object. They are the key design space dimensions to consider.

![Metadata section](/images/arch-design-section-metadata.png "Metadata section")

// TODO Insert sub article

## Consistency

Consistency interleaves the core spine of distributed storage system design. The techniques have high variety and touch most components. I choose __scale__ as the first level category to illustrate consistency design space: from single node level, datacenter level, to geo-regional level. In general, key design space dimensions to consider are below. See [Distributed Transactions][294] for more.

![Consistency section](/images/arch-design-section-consistency.png "Consistency section")

// TODO Insert sub article

## Write path

The next big component in a distributed storage system is write path, following which you characterize how a system works. Append-only or update in-place fundamentally divides system styles and next level techniques. Write path touches almost every other components in a system, e.g. metadata, index, data organization, logging, replication, and many system properties, e.g. consistency, durability, amplification. Read path can be seen as a reflection of write path, plus caching to optimize performance.

![Write path section](/images/arch-design-section-write-path.png "Write path section")

// TODO Insert sub article

## Data organization

Traditionally "data organization" talks about physical columnar/row-wise data layouts in databases. I choose to view data organization from a broader perspective which is divided by purposes. Essentially, query tier carries the most DB techniques when it wants to be performant, while durability/scaleout tiers are orthogonal from it and can be offloaded to a shared storage system, and performance tier is usually addressed by caching. We focus on query tier for data organization, and discuss performance/scaleout tiers in other sections.

![Data organization section](/images/arch-design-section-data-organization.png "Data organization section")

// TODO Insert sub article

## Data indexing

Data indexes commonly reside in memory (i.e. DRAM) and forward links to data. Though residing in PMEM is possible but by far it's still slower than DRAM. Data indexes stem from standard textbook data structures, evolve into more complexity for industrial use, and scaleout in distributed systems. They serve read queries, point where to write, and carry a cost to maintain consistency with data.

![Data indexing section](/images/arch-design-section-data-indexing.png "Data indexing section")

// TODO Insert sub article

## Data caching

Data caching resolves the performance tier in data organization. It exploits the skewness of data hotness and temporal access locality, to trade off expensive small capacity storage media with fast access. Internet services commonly heavily leverage cache (e.g. Redis) to serve most user data. We first plot the design space of data caching by categorizing its different properties.

![Data caching section](/images/arch-design-section-data-caching.png "Data caching section")

// TODO Insert sub article

## Data partitioning & placement

Data partitioning is the fundamental paradigm to __scaleout__ data serving in a distributed system. It has more design properties, that many also resemble those in [Data organization section](.), where you can find partitioning across nodes is like co-locating data in chunks. Data sharding is mostly a synonym of data partitioning. Data placement is the next step that decides which node to place a partition. Usually data partitioning and placement are joined together to solve the design properties.

![Data partitioning section](/images/arch-design-section-data-partitioning.png "Data partitioning section")

// TODO Insert sub article

## Data integrity

Data integrity is critical. A storage system can be slow, feature less, non-scalable, but it should never lose data. There are several failure patterns affecting data integrity. Replication and CRC are plain techniques used to improve data integrity.

![Data integrity section](/images/arch-design-section-data-integrity.png "Data integrity section")

// TODO Insert sub article

## Resource scheduling

Multi-dimensional resource scheduling on cloud is a big topic, see DRF/2DFQ etc mentioned in [Reference architectures section](.). In this section I cover system properties in a typical storage system. There are a few design dimensions to consider when designing resource scheduling.

![Resource scheduling section](/images/arch-design-section-resource-scheduling.png "Resource scheduling section")

// TODO Insert sub article

## Performance

Though running the system fast is the most typical meaning of performance, performance maps to more system __properties__: latency & throughput, predictable performance, scalability, Resource efficiency, etc. Exploiting concurrency & parallelism is one of the key techniques to improve performance.

![Performance section](/images/arch-design-section-performance.png "Performance section")

// TODO Insert sub article

## Networking

Networking is generally orthogonal to storage design. It's more attached to datacenter construction and hardware equipment. It affects storage system in various aspects. Compared to the other parts of a storage system, networking has several key differences. The fundamental level is networking architecture. It constraints the baseline performance and scalability.

![Networking section](/images/arch-design-section-networking.png "Networking section")

// TODO Insert sub article

## More topics

Compared to [Storage components breakdown section](.), there are a few topics I didn't cover.

// TODO Insert sub article

# Conclusion

This article (almost a book now) is composed of two parts: software __architecture methodologies__ and storage __technology design spaces__. In the first part, we went through the purposes of software architecture, how to view it from the organization, the process to carry it out, and key methodologies and principles. Software architecture bridges user scenarios to a detailed working software. It handles the complexity of user facing functions and hidden system properties. It navigates through the best path in large technology design space. It drives collaboration between BUs and ensures the deliverables with quality. Software architecture is a fight with complexity. It constructs the matching model with human mind to reach simplicity, which naturally converges to human language, the battle-tested modeling of the reality. It becomes an __art of structuring__, to sense the influences between organization chains, the momentum from customer markets, the tension between system properties and technologies, that weaves transforming information flows into flying wheels of software construction.

In the second part, we went through technology design spaces for the distributed storage system. We first listed __Reference architectures__ in different storage areas, and then breakdown each storage component's system properties and design spaces. [Storage components breakdown section](.) lists the storage areas, components, and system properties to consider in software architecture. Popular techniques burn into language and becomes a design pattern. An __architecture design pattern__ frequently interleaves multiple components and trade-off between system properties. Discrete techniques join into a __continuous space of design__, where the shape of landscape emerges. We breakdown, navigate, and re-combine whatever we need to reach the optimal point of problem solution. Storage industry is quickly changing, with more powerful hardware, growing scale, new business scenarios, and a constant focus on reliability and COGS. They push technology design space to continuously evolve. New opportunities emerge.

# References

// TODO Insert sub article
