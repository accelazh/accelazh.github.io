这是长篇“分布式存储架构和设计空间”的第十四篇。全文很长，受微信公众号限制，需要分P发出。全文将依次总结各存储组件的技术和设计空间，本章总结一些学习来源。

# 概述

软件架构有共同的 __系统属性__，例如[_CAP_](.)[52]。为了实现这些特性，人们发明了不同的技术，并演变成更普遍的 __架构设计模式__。将它们绘制在各种驱动因素的地图上，它们揭示了 __技术设计空间__ 的地形，我们为构建新系统而探索和导航。我将专注于 __分布式存储__。

## 可以学习的来源

文章、书籍和课程教授设计模式，并概述了设计空间的情况。

  * MartinFowler网站[_分布式系统的模式_](.)[53]。随着云计算的采用，像[_一致性核心_](.)[54]和[_复制的日志_](.)[55]这样的模式正在得到普及。除了这一条，服务注册中心、Sidecar、Circuit Breaker、Shared Nothing也是流行的模式。

  * Azure文档中的[_云设计模式_](.)[56]也总结了常见的云原生应用设计模式。它们得到了详细的解释，并填补了上面所遗漏的内容。

  * [_设计数据密集型应用_](.)[57]一书展示了分布式系统的挑战、解决方案和技术。他们映射到设计模式并结合到设计空间。

  * 课程 [_CMU 15-721_](.)[58] 概述了数据库设计中的关键组件，例如MVCC、数据压缩、查询调度、连接。分解揭示了要探索的设计空间。所附的论文未来游既定的设计模式的深度。非常有价值。

  * [_On Designing and Deploying Internet-Scale Services_](.)[59]。这篇文章全面、深入，涵盖了构建互联网规模服务的最佳实践的各个方面。非常有价值。它让我想起了[_SteveY的评论_](.)[60]。

公认的开源和工业系统成为 __参考架构__，以此来学习流行的技术或设计模式。下文列出我快速记起的东西（可能 __不完整__ ）。参考架构可以通过搜索顶级产品，比较供应商的备选方案，或者从具有高度参考价值的基石论文中找到。

  * 因本节过长，在下一[参考架构章节](.)中列出。// TODO 插入子文章

慷慨地分享知识的论文中，相关作品部分，对于比较当前作品和揭示设计空间非常有用，比如：

  * [_TiDB_](.)[61]论文和[_Greenplum_](.)[62]论文的相关作品部分显示了互相竞争的市场产品如何基于之前的OLTP或OLAP支持HTAP（混合事务和分析处理）。它们还揭示了所采用的技术和优缺点。

优质的论文和调查（Survey）可以揭示技术空间，达到相当的广度和深度。

  * [_基于LSM的存储技术：调查_](.)[63] ([_Zhihu_](.)[64]) 调查了用于优化LSM树的技术的全部书目，并组织了非常有用的分类法。

![基于LSM的存储技术：A Survey](/images/arch-design-space-lsm-survey.png "基于LSM的存储技术：A Survey")。

  * [_Scaling Replicated State Machines with Compartmentalization_](.)[65] 展示了一组技术，以解耦Paxos组件并优化吞吐量。

![Scaling Replicated State Machines with Compartmentalization](/images/arch-design-space-paxos-compartment.png "Scaling Replicated State Machines with Compartmentalization" )

  * [_An Empirical Evaluation of In-Memory Multi-Version Concurrency Control_](.)[66] 比较了主流数据库如何实现MVCC与品种，提取了常见的MVCC组件，并讨论了主要技术。这也是理解MVCC的有用指南。

![An Empirical Evaluation of In-Memory Multi-Version Concurrency Control](/images/arch-design-space-in-mem-mvcc.png "An Empirical Evaluation of In-Memory Multi-Version Concurrency Control" )

  * [_内存大数据管理和处理_](.)[67]调查了主流内存数据库和设计的方式，比较了它们的关键技术，这就形成了设计空间。

![内存大数据管理和处理](/images/arch-design-space-in-mem-db.png "内存大数据管理和处理")

  * [_Constructing and Analyzing the LSM Compaction Design Space_](.)[68] 比较了基于LSM树的存储引擎中的不同压缩策略。论文里面有更多细化的表格。

![构建和分析LSM压缩设计空间](/images/arch-design-space-lsm-compaction.png "构建和分析LSM压缩设计空间" )

  * 另一个[_Dostoevsky: Better Space-Time Trad-Offs for LSM-Tree_](.)[69]也绘制了更新、点查找、范围查找的时空权衡的设计空间。

![Dostoevsky: Better Space-Time Trade-Offs for LSM-Tree](/images/arch-design-space-dostoevsky.png "Dostoevsky: 更好的LSM-树的时空权衡")

  * [_数据库系统中的无锁同步_](.)[70]比较了常见的有锁/无锁技术，例如CAS、TATAS、xchgq、pthread、MCS，针对不同的并发级别。它揭示了在实现有效的B+树锁技术时的选择空间。

  * [_Optimal Column Layout for Hybrid Workloads_](.)[71]对CRUD、点/范围查询、随机/顺序读/写的成本函数按分区大小如何划分区块进行建模。它有助于找到最佳的块物理布局。

  * [_主内存优化数据系统中的访问路径选择_](.)[72] 在不同的结果选择性和查询共享并发性下，使用全扫描与B+树的查询成本模型。该成本模型显示了查询优化器如何选择物理计划。
