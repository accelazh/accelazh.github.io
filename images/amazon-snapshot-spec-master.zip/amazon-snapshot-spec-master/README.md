# Formal Specs of Database Isolation

Done by Chris Newcombe at Amazon for [this talk](http://hpts.ws/papers/2011/sessions_2011/Debugging.pdf) at [HPTS 2011](http://hpts.ws/papers/2011/agenda.html) and not used at Amazon. Verified with distributed TLC.
