########################################################
# Regenerating code construct by paper "Explicit constructions
# of high-rate MDS array codes with optimal repair bandwidth".
#
# It is row-wise MDS, needs no extra storage overhead, and
# recovers single node failure by half (or more specifically,
# 1/parity_fragment_count) of the total bandwidth, compared
# to Read-Solomon code.
#
# The down side is this regenerating code shema requires
# parity_fragment_count^total_fragment_count rows on each
# node. It is too many rows for long code.
########################################################

import os
import random
import time
import galois_matrix as galois


def demo_regenerating(data_node_count, node_to_kill):
	BIT_VALUES = [0, 1]

	DATA_NODE_COUNT = int(data_node_count)
	PARITY_NODE_COUNT = 2
	NODE_TO_KILL = int(node_to_kill)

	assert DATA_NODE_COUNT >= 2
	assert NODE_TO_KILL >= 0
	assert NODE_TO_KILL < DATA_NODE_COUNT + PARITY_NODE_COUNT

	ROW_BIT_COUNT = DATA_NODE_COUNT + PARITY_NODE_COUNT
	ROW_COUNT = 1 << ROW_BIT_COUNT
	
	#
	# Generate the user data 
	#

	user_data = []
	for idx in range(0, ROW_COUNT * DATA_NODE_COUNT):
		user_data.append(random.randint(0, (1 << galois.WORD_SIZE) - 1))

	print("User input data:")

	for row in range(0, int(len(user_data) / DATA_NODE_COUNT)):
		print("  ", end="")
		for col in range(0, DATA_NODE_COUNT):
			print("%d, " % user_data[row * DATA_NODE_COUNT + col],
				  end="")
		print("")
	print("User data size:", len(user_data), "units")
	print("")

	#
	# Find the lambda matrix
	#

	print("Searching for the appropriate lambda matrix ...")

	lamda = []
	picking_lamda = 0
	for col in range (0, DATA_NODE_COUNT + PARITY_NODE_COUNT):
		row = []
		for bit in BIT_VALUES:
			row.append(picking_lamda)
			print("lambda%d,%d = %d\t" % (col + 1, bit, picking_lamda),
				  end="", flush=True)
			picking_lamda += 1
			assert picking_lamda < (1 << galois.WORD_SIZE), \
			       "picking_lamda cannot exceed galois field size"
		lamda.append(row)
		print("")
	print("")

	#
	# Evaluating the recoverability of lambda matrix
	#

	print("Verifying lambda matrix MDS recoverability ...")

	full_recoverable = True
	for col1 in range (0, DATA_NODE_COUNT + PARITY_NODE_COUNT):
		for col2 in range (col1 + 1, DATA_NODE_COUNT + PARITY_NODE_COUNT):
			print("Verifying MDS: recovering from node %d, %d"
				  % (col1 + 1, col2 + 1))
			for bit1 in BIT_VALUES:
				for bit2 in BIT_VALUES:
					matrix = [
						[1, 1],
						[lamda[col1][bit1], lamda[col2][bit2]]
					]
					if not galois.matrix_invert(matrix):
						full_recoverable = False
						print("Failed to recover!")
						assert False
	if full_recoverable:
		print("MDS recoverability verified:"
			  " any %d nodes can recover another %d nodes"
			  % (DATA_NODE_COUNT, PARITY_NODE_COUNT))
	print("")

	#
	# Preparing data nodes
	#

	print("Replicating user data into data nodes ...")

	nodes = []
	for col in range(0, DATA_NODE_COUNT + PARITY_NODE_COUNT):
		nodes.append([])

	for row in range(0, ROW_COUNT):
		print("Copying row", ("{0:0%db}" % ROW_BIT_COUNT).format(row), "...")
		for col in range(0, DATA_NODE_COUNT):
			nodes[col].append(
				user_data[DATA_NODE_COUNT * row + col])

	data_size = 0
	for col in range(0, DATA_NODE_COUNT):
		data_size += len(nodes[col])
	print("Replication done, data size:", data_size, "units")
	print("")

	#
	# Calculating parity nodes
	#

	for row in range(0, ROW_COUNT):
		sum_data = 0
		sum_data_lamda = 0
		for col in range(0, DATA_NODE_COUNT):
			sum_data = galois.add(sum_data, nodes[col][row])
			zero_or_one = 1 if ((row & (1 << col)) != 0) else 0
			sum_data_lamda = galois.add(
				sum_data_lamda,
				galois.mul(
					lamda[col][zero_or_one],
					nodes[col][row]))
		matrix_right = [
			[galois.neg(sum_data)],
			[galois.neg(sum_data_lamda)]
		]
		
		matrix_left_top = []
		matrix_left_bottom = []
		for col in range(
				DATA_NODE_COUNT,
				DATA_NODE_COUNT + PARITY_NODE_COUNT):
			matrix_left_top.append(1)
			zero_or_one = 1 if ((row & (1 << col)) != 0) else 0
			matrix_left_bottom.append(lamda[col][zero_or_one])
		matrix_left = [
			matrix_left_top,
			matrix_left_bottom
		]

		matrix_left_inverted = galois.matrix_invert(matrix_left)
		assert matrix_left_inverted != False, "Must be invertible. We checked it before."

		matrix_ret = galois.matrix_mul(matrix_left_inverted, matrix_right)
		for col in range(0, PARITY_NODE_COUNT):
			nodes[col + DATA_NODE_COUNT].append(matrix_ret[col][0])

	print("Parities calculated, dumping data at each nodes ...")

	for row in range(0, ROW_COUNT):
		print("Row %s: " % ("{0:0%db}" % ROW_BIT_COUNT).format(row),
			  end="")
		for col in range(0, DATA_NODE_COUNT + PARITY_NODE_COUNT):
			print("{0:<4d}".format(nodes[col][row]), end="")
		print("")
	print("")

	#
	# Kill the specified node to simulate node loss
	#
	print("Killing node %d ..." % NODE_TO_KILL)
	for row in range(0, ROW_COUNT):
		nodes[NODE_TO_KILL][row] = -1
	print("Node %d killed. Data cleared." % NODE_TO_KILL)
	print("")

	#
	# Perform Reed-solomon MDS recovery
	# 

	print("Performing the plain Reed-solomon MDS recovery ...")

	selected_nodes = []
	for col in reversed(range(0, DATA_NODE_COUNT + PARITY_NODE_COUNT)): # For fun, select parity first
		if col == NODE_TO_KILL:
			continue
		selected_nodes.append(col)
		if (len(selected_nodes) >= DATA_NODE_COUNT):
			break
	assert len(selected_nodes) == DATA_NODE_COUNT

	print("Transmitting from", selected_nodes, "to killed node", NODE_TO_KILL, "...")

	unselected_nodes = [NODE_TO_KILL]
	for col in range(0, DATA_NODE_COUNT + PARITY_NODE_COUNT):
		if col == NODE_TO_KILL:
			continue
		if col in selected_nodes:
			continue
		unselected_nodes.append(col)
	assert len(unselected_nodes) == PARITY_NODE_COUNT

	transferred_data = 0
	for row in range(0, ROW_COUNT):
		sum_data = 0
		sum_data_lamda = 0
		for col in selected_nodes:
			sum_data = galois.add(sum_data, nodes[col][row])
			zero_or_one = 1 if ((row & (1 << col)) != 0) else 0
			sum_data_lamda = galois.add(
				sum_data_lamda,
				galois.mul(
					lamda[col][zero_or_one],
					nodes[col][row]))
			transferred_data += 1
		matrix_right = [
			[galois.neg(sum_data)],
			[galois.neg(sum_data_lamda)]
		]

		matrix_left_top = []
		matrix_left_bottom = []
		for col in unselected_nodes:
			matrix_left_top.append(1)
			zero_or_one = 1 if ((row & (1 << col)) != 0) else 0
			matrix_left_bottom.append(lamda[col][zero_or_one])
		matrix_left = [
			matrix_left_top,
			matrix_left_bottom
		]

		matrix_left_inverted = galois.matrix_invert(matrix_left)
		assert matrix_left_inverted != False, \
		       "Must be invertible. We checked it before."

		matrix_ret = galois.matrix_mul(matrix_left_inverted, matrix_right)
		nodes[NODE_TO_KILL][row] = matrix_ret[0][0]

		print("Recovered row %s" % ("{0:0%db}" % ROW_BIT_COUNT).format(row))
	rsmds_transfer_ratio = transferred_data / len(user_data)
	print("Transferred data %d units. Transferred / user data size = %f."
		  % (transferred_data, rsmds_transfer_ratio))
	print("")

	#
	# Verify the data correctness after recovery
	#

	print("Verifying recovered data correctness ...")

	for row in range(0, ROW_COUNT):
		for col in range(0, DATA_NODE_COUNT):
			assert nodes[col][row] == user_data[row * DATA_NODE_COUNT + col], \
			       "Data correctness verification failed at (%d, %d)" % (row, col)
	print("Passed.")
	print("")

	#
	# Kill the specified node to simulate node loss
	#

	print("Killing node %d again ..." % NODE_TO_KILL)
	for row in range(0, ROW_COUNT):
		nodes[NODE_TO_KILL][row] = -1
	print("Node %d killed. Data cleared." % NODE_TO_KILL)
	print("")

	#
	# Perform regenerating code recovery
	#

	print("Performing the regenerating code recovery ...")

	selected_nodes = [col for col in range(0, DATA_NODE_COUNT + PARITY_NODE_COUNT) \
	            		if col != NODE_TO_KILL]
	print("Transmitting from", selected_nodes, "to killed node", NODE_TO_KILL, "...")

	transferred_data = 0
	for row in range(0, ROW_COUNT):
		zero_or_one = 1 if ((row & (1 << NODE_TO_KILL)) != 0) else 0
		if (zero_or_one != 0):
			continue

		zero_row = row
		assert (row & (1 << NODE_TO_KILL)) == 0
		one_row = (row | (1 << NODE_TO_KILL))

		print("Recovering row %s and row %s ... " % (
				("{0:0%db}" % ROW_BIT_COUNT).format(zero_row),
				("{0:0%db}" % ROW_BIT_COUNT).format(one_row),
			 ), end="", flush=True)

		sum_data = 0
		sum_data_lamda = 0

		for col in range(0, DATA_NODE_COUNT + PARITY_NODE_COUNT):
			if NODE_TO_KILL == col:
				continue
			
			zero_or_one = 1 if ((row & (1 << col)) != 0) else 0
			zero_or_one_by_one_row = (1 if ((one_row & (1 << col)) != 0)
										else 0)
			assert zero_or_one_by_one_row == zero_or_one

			sum_two_rows = galois.add(
				nodes[col][zero_row],
				nodes[col][one_row])
			transferred_data += 1

			sum_data = galois.add(sum_data, sum_two_rows)
			sum_data_lamda = galois.add(
				sum_data_lamda,
				galois.mul(
					lamda[col][zero_or_one],
					sum_two_rows))
		
		matrix_right = [
			[galois.neg(sum_data)],
			[galois.neg(sum_data_lamda)]
		]

		matrix_left_top = []
		matrix_left_bottom = []
		
		for bit in BIT_VALUES:
			matrix_left_top.append(1)
			zero_or_one = bit
			matrix_left_bottom.append(lamda[NODE_TO_KILL][zero_or_one])
		
		matrix_left = [
			matrix_left_top,
			matrix_left_bottom
		]
		
		matrix_left_inverted = galois.matrix_invert(matrix_left)
		assert matrix_left_inverted != False, \
		       "Must be invertible. We checked it before."
		
		matrix_ret = galois.matrix_mul(matrix_left_inverted, matrix_right)
		for bit_idx in range(0, len(BIT_VALUES)):
			bit = BIT_VALUES[bit_idx]
			if 0 == bit:
				target_row = row
			elif 1 == bit:
				target_row = (row | (1 << NODE_TO_KILL))
			else:
				assert False

			assert nodes[NODE_TO_KILL][target_row] == -1, \
			       "Data should be cleared before recovery"
			nodes[NODE_TO_KILL][target_row] = matrix_ret[bit_idx][0]
			
			if NODE_TO_KILL < DATA_NODE_COUNT:
				assert nodes[NODE_TO_KILL][target_row] \
				       == user_data[target_row * DATA_NODE_COUNT + NODE_TO_KILL], \
				       "Data verification failed"

		print("Done")
	regenerating_transfer_ratio = transferred_data / len(user_data)
	print("Transferred data %d units. Transferred / user data size = %f."
		  % (transferred_data, regenerating_transfer_ratio))
	print("")
		
	#
	# Verify the data correctness after recovery
	#

	print("Verifying recovered data correctness ...")

	for row in range(0, ROW_COUNT):
		for col in range(0, DATA_NODE_COUNT):
			assert nodes[col][row] == user_data[row * DATA_NODE_COUNT + col], \
			       "Data correctness verification failed at (%d, %d)" % (row, col)
	print("Passed.")
	print("")


	#
	# Summarize the recovery bandwidth comparison
	#

	print("Recover by Reed-Solomon MDS:")
	print("  %d data units transferred, %f of original user data size"
		  % (int(rsmds_transfer_ratio * len(user_data)), rsmds_transfer_ratio))

	print("Recover by regenerating code:")
	print("  %d data units transferred, %f of original user data size"
		  % (int(regenerating_transfer_ratio * len(user_data)), regenerating_transfer_ratio))

	print("")
	print("Regenerating code reduces total bandwidth to:")
	print("  %.2f%%" % (regenerating_transfer_ratio / rsmds_transfer_ratio * 100))


def main():
	galois.tests()
	print("")

	demo_regenerating(10, 9)
	print("")

if __name__ == "__main__":
    main()