import os
import random

WORD_SIZE = 8
GENERATOR_LOW = 29    # low order terms of generator g(x)=x^8 + x^4 + x^3 + x^2 + 1

MUL_TABLE = None
DIV_TABLE = None

def add(a, b):
    return a ^ b

def subtract(a, b):
    """ return a - b """
    return a ^ b

def mul_raw(a, b):
    prod = 0

    # Multiply pharse
    for k in range(0, WORD_SIZE):
        if (a & 1):
            prod ^= (b << k)
        a >>= 1
        if (a == 0):
            break

    # Reduce pharse
    mask = 1 << WORD_SIZE
    mask <<= WORD_SIZE - 2
    for k in reversed(range(0, WORD_SIZE - 2 + 1)):
        if (prod & mask):
            prod &= ~mask
            prod ^= (GENERATOR_LOW << k)
        mask >>= 1

    return prod

def setup_mul_table():
    global MUL_TABLE

    print("Populating galois MUL_TABLE ...")
    MUL_TABLE = []
    for i in range(0, 1 << WORD_SIZE):
        row = []
        for j in range(0, 1 << WORD_SIZE):
            row.append(mul_raw(i, j))
        MUL_TABLE.append(row)

def mul(a, b):
    if (MUL_TABLE == None):
        setup_mul_table()

    return MUL_TABLE[a][b]

def neg(a):
    return subtract(0, a)

def gpow(a, p):
    prod = 1
    for k in range(0, p):
        prod = mul(prod, a)
    return prod

def setup_div_table():
    global DIV_TABLE
    if (MUL_TABLE == None):
        setup_mul_table()

    print("Populating galois DIV_TABLE ...")
    DIV_TABLE = []

    for i in range(0, 1 << WORD_SIZE):
        row = []
        for j in range(0, 1 << WORD_SIZE):
            row.append(0)
        DIV_TABLE.append(row)

    for i in range(0, 1 << WORD_SIZE):
        for j in range(0, 1 << WORD_SIZE):
            DIV_TABLE[MUL_TABLE[i][j]][i] = j

    for i in range(0, 1 << WORD_SIZE):
        for j in range(0, 1 << WORD_SIZE):
            if 0 == j:
                continue

            if i != 0:
                assert(DIV_TABLE[i][j] != 0)
            else:
                assert(DIV_TABLE[i][j] == 0)

def div(a, b):
    if (DIV_TABLE == None):
        setup_div_table()

    if (b == 0):
        raise ZeroDivisionError("div(%s, %s)" % (a, b))
    return DIV_TABLE[a][b]

def matrix_copy(m):
    mcp = []
    for vi in m:
        row = []
        for vj in vi:
            row.append(vj)
        mcp.append(row)
    return mcp

def matrix_row_switch(m, r1, r2):
    r_switch = m[r1]
    m[r1] = m[r2]
    m[r2] = r_switch
    return m

def matrix_row_subtract(m, r1, r2, a=1):
    """ m's row r1 = r1 - r2 * a """
    for j, vj in enumerate(m[r1]):
        m[r1][j] = subtract(vj, mul(m[r2][j], a))

def matrix_row_mul(m, r, a):
    for j, vj in enumerate(m[r]):
        m[r][j] = mul(vj, a)
    return m

def matrix_mul(m1, m2):
    """ return m1 * m2 """
    if (len(m1[0]) != len(m2)):
        raise ValueError("m1's column size should be equal to m2's row size")

    m = []
    for i in range(0, len(m1)):
        row = []
        for j in range(0, len(m2[0])):
            v = 0
            for k in range(0, len(m1[i])):
                v = add(v, mul(m1[i][k], m2[k][j]))
            row.append(v)
        m.append(row)

    return m

def matrix_add(m1, m2):
    if (len(m1) != len(m2)):
        raise ValueError("m1's row count should be equal to m2's row count")
    if len(m1) == 0:
        return []
    if (len(m1[0]) != len(m2[0])):
        raise ValueError("m1's column count should be equal to m2's column count")

    ret = []
    for ri in range(0, len(m1)):
        ret_row = []
        for ci in range(0, len(m1[0])):
            ret_row.append(add(m1[ri][ci], m2[ri][ci]))
        ret.append(ret_row)
    return ret

def matrix_subtract(m1, m2):
    if (len(m1) != len(m2)):
        raise ValueError("m1's row count should be equal to m2's row count")
    if len(m1) == 0:
        return []
    if (len(m1[0]) != len(m2[0])):
        raise ValueError("m1's column count should be equal to m2's column count")

    ret = []
    for ri in range(0, len(m1)):
        ret_row = []
        for ci in range(0, len(m1[0])):
            ret_row.append(subtract(m1[ri][ci], m2[ri][ci]))
        ret.append(ret_row)
    return ret

def matrix_identity(rows, cols):
    m = []
    for i in range(0, rows):
        row = []
        for j in range(0, cols):
            if (i == j):
                row.append(1)
            else:
                row.append(0)
        m.append(row)
    return m

def matrix_transpose(m):
    """ return m^T, i.e. flip by diagonal line """
    mf = []
    for i in range(0, len(m[0])):
        row = []
        for j in range(0, len(m)):
            row.append(m[j][i])
        mf.append(row)
    return mf

def matrix_topdown(m):
    """ flip m top down, and return the new matrix """
    mtd = []
    for i in range(0, len(m)):
        row = []
        for j in range(0, len(m[0])):
            row.append(m[len(m)-i-1][j])
        mtd.append(row)
    return mtd

def matrix_invert(m):
    """ Invert a matrix m to m^-1
        m will be transformed to identity matrix, or the corresponding if
        m doesn't have equal numbers of rows and columns.
        return False if not invertible, else return inverted m, i.e. m^-1
    """
    if (len(m) > len(m[0])):
        raise ValueError("Passed in matrix m should not have more rows than cols")

    msize = len(m)
    mid = matrix_identity(msize, msize)

    # Transform m to identity matrix
    for row in range(0, msize):
        # Let's find a row whose m[row][row] != 0
        for i in range(row, msize):
            if (m[i][row] != 0):
                matrix_row_switch(m, row, i)
                matrix_row_switch(mid, row, i)
                break
        if (m[row][row] == 0):
            # We can't find such row, matrix is not invertible
            return False

        # Eliminate all elements in current column
        for i in range(0, msize):
            if (i == row or m[i][row] == 0):
                continue
            a = div(m[i][row], m[row][row])
            matrix_row_subtract(m, i, row, a)
            matrix_row_subtract(mid, i, row, a)

        #print("matrix inverting, row=%d:" % row, matrix_sprint(m))

        # Make current m[row][row] to 1
        a = div(1, m[row][row])
        matrix_row_mul(m, row, a)
        matrix_row_mul(mid, row, a)

    # Assert the left msize*msize block of m is an identity matrix
    for i in range(0, msize):
        for j in range(0, msize):
            if (i == j):
                assert(m[i][j] == 1)
            else:
                assert(m[i][j] == 0)

    # mid should now be m's invert matrix
    return mid

def proceed_combo(combo, idx, size):
    """ Iterate through all combinations C(size, idx) 
        For example, pass in below (combo, idx=(len(combo)-1), 10),
        the combo proceeds by every invoke
            combo: [0, 1, 2, 3, 4]
            combo: [0, 1, 2, 3, 5]
            ...
            combo: [0, 1, 2, 5, 9]
            combo: [0, 1, 2, 6, 7]
            ...
            combo: [0, 1, 2, 6, 9]
            combo: [0, 1, 2, 7, 8]
            ...
            combo: [2, 6, 7, 8, 9]
            combo: [3, 4, 5, 6, 7]
            ...
            combo: [4, 6, 7, 8, 9]
            combo: [5, 6, 7, 8, 9]
    """
    if idx < 0:
        return False
    elif (combo[idx] < size - 1):
        combo[idx] += 1
        return True
    else:
        if (not proceed_combo(combo, idx - 1, size - 1)):
            return False
        combo[idx] = combo[idx - 1] + 1
        assert(combo[idx] < size)
        return True

def generate_vandermonde(rows, cols):
    m = []
    for i in range(0, rows):
        row = []
        for j in range(0, cols):
            row.append(gpow(j+1, i))
        m.append(row)
    return m

def generate_cauchy(rows, cols):
    m = []
    for i in range(0, rows):
        row = []
        for j in range(0, cols):
            row.append(div(1, add(i, rows + j)))
        m.append(row)
    return m

def matrix_sprint(m):
    s = "[" + os.linesep \
    + "\t" \
    + (os.linesep + "\t").join(",\t".join(str(vj) for vj in vi) for vi in m) \
    + os.linesep + "]"
    return s

def sorted_array_contains_array(arr_big, arr):
    """ return True if every elements of arr occurs in arr_big """
    i = 0
    j = 0
    matched = 0
    while (i < len(arr_big) and j < len(arr)):
        if (arr_big[i] < arr[j]):
            i += 1
        elif (arr_big[i] > arr[j]):
            j += 1
        else:
            matched += 1
            i += 1
            j += 1
    return matched >= len(arr)

def submatrix(m, rows, cols):
    ret = []
    for r in rows:
        ret_row = []
        for c in cols:
            ret_row.append(m[r][c])
        ret.append(ret_row)
    return ret

def all_submatrix_invertible(m, filter=None):
    """ Determine whether all submatrixes are invertible
        If filter(rows, cols) is False, the submatrix by (rows, cols) will be bypassed
        Return True, if all submatrixes are invertible
        Return the first uninvertible submatrix's (rows, cols), if not all invertible
    """
    row_count = len(m)
    col_count = len(m[0])
    max_size = min(row_count, col_count) + 1

    #
    # We first try random submatrixes. This can usually quickly help find
    # uninvertible submatrixes
    #

    case_count = min(100, row_count * col_count)
    if (max_size <= 3):
        case_count = 0
    
    tried_case_count = 0
    while tried_case_count < case_count:
        size = random.sample(range(2, max_size), 1)[0]
        rows = random.sample(range(0, row_count), size)
        cols = random.sample(range(0, col_count), size)

        if (filter is not None) and (not filter(rows, cols)):
            continue

        subm = submatrix(m, rows, cols)
        if not matrix_invert(subm):
            return (rows, cols)

        tried_case_count += 1

    #
    # Next, we fully walkthrough each submatrixes
    #

    all_invertible = True
    for size in range(1, max_size):
        rows = list(range(0, size))
        while all_invertible:
            cols = list(range(0, size))
            while all_invertible:
                
                if ((filter is None) or filter(rows, cols)):
                    subm = submatrix(m, rows, cols)
                    if not matrix_invert(subm):
                        return (rows, cols)

                if not proceed_combo(cols, len(cols) - 1, col_count):
                    break 
            if not proceed_combo(rows, len(rows) - 1, row_count):
                break

    return True

def generate_random_matrix(rows, cols):
    m = []
    for r in range(0, rows):
        row = []
        for c in range(0, cols):
            row.append(random.randint(0, (1 << WORD_SIZE) - 1))
        m.append(row)
    return m

def test_by_text_book():
    global WORD_SIZE, GENERATOR_LOW
    ORIGINAL_WORD_SIZE = WORD_SIZE
    ORIGINAL_GENERATOR_LOW = GENERATOR_LOW

    WORD_SIZE = 3
    GENERATOR_LOW = 3

    assert(add(1, 2) == 3)
    assert(add(7, 4) == 3)

    assert(mul_raw(2, 4) == 3)
    assert(mul_raw(4, 2) == 3)
    assert(mul_raw(7, 7) == 3)
    assert(mul_raw(4, 1) == 4)
    assert(mul_raw(5, 0) == 0)
    assert(mul_raw(2, 6) == 7)
    assert(mul_raw(3, 2) == 6)
    assert(mul_raw(1, 5) == 5)
    assert(mul_raw(6, 4) == 5)

    WORD_SIZE = ORIGINAL_WORD_SIZE
    GENERATOR_LOW = ORIGINAL_GENERATOR_LOW

def test_gpow():
    assert(mul_raw(11, 11) == 69)
    assert(mul_raw(12, 12) == 80)
    assert(mul_raw(20, 20) == 13)

    assert(gpow(13, 3) == 186)
    assert(gpow(18, 3) == 191)

    assert(gpow(4, 4) == 29)
    assert(gpow(14, 4) == 192)
    assert(gpow(19, 4) == 93)

    assert(gpow(2, 5) == 32)
    assert(gpow(10, 5) == 1)
    assert(gpow(20, 5) == 32)

    assert(gpow(12, 0) == 1)

def test_mul():
    for i in range(0, 1 << WORD_SIZE):
        for j in range(0, 1 << WORD_SIZE):
            assert(mul(i, j) == mul_raw(j, i))

def test_gpow():
    assert(gpow(12, 3) == mul(mul(12, 12), 12))
    assert(gpow(13, 1) == 13)
    assert(gpow(14, 0) == 1)

def test_div():
    assert(mul_raw(div(122, 9), 9) == 122)
    assert(mul_raw(div(2, 129), 129) == 2)
    assert(mul_raw(div(55, 2), 2) == 55)
    assert(mul_raw(div(1, 213), 213) == 1)
    assert(mul_raw(div(10, 1), 1) == 10)

    for i in range(0, 1 << WORD_SIZE):
        for j in range(1, 1 << WORD_SIZE):
            assert(mul(div(i, j), j) == i)

    for i in range(1, 1 << WORD_SIZE):
        assert(div(0, i) == 0)

def test_matrix_operations():
    m = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16],
        [17, 18, 19, 20],
    ]

    # test matrix copy
    mcp = matrix_copy(m)
    assert(mcp is not m)
    assert(mcp == m)
    for i, vi in enumerate(mcp):
        for j, vj in enumerate(vi):
            assert(vj == m[i][j])

    # test matrix row switch
    mcp = matrix_copy(m)
    matrix_row_switch(mcp, 1, 3)
    assert(mcp[0][1] == 2)
    assert(mcp[1][2] == 15)
    assert(mcp[3][3] == 8)

    # test matrix switch the same row
    mcp = matrix_copy(m)
    matrix_row_switch(mcp, 2, 2)
    assert(mcp[2][1] == 10)
    assert(mcp[2][3] == 12)
    assert(mcp == m)

    # test matrix row subtract
    mcp = matrix_copy(m)
    matrix_row_subtract(mcp, 2, 4)
    assert(mcp[4][3] == 20)
    assert(mcp[2][0] == subtract(9, 17))
    assert(mcp[2][3] == subtract(12, 20))

    # test matrix row subtract with multiple
    mcp = matrix_copy(m)
    matrix_row_subtract(mcp, 2, 4, 111)
    assert(mcp[4][0] == 17)
    assert(mcp[2][0] == subtract(9, mul(17, 111)))
    assert(mcp[2][3] == subtract(12, mul(20, 111)))

    # test matrix row mul
    mcp = matrix_copy(m)
    matrix_row_mul(mcp, 3, 129)
    assert(mcp[4][2] == 19)
    assert(mcp[3][0] == mul(13, 129))
    assert(mcp[3][2] == mul(15, 129))
    assert(mcp[3][3] == mul(16, 129))

    # test matrix mul
    m2 = [
        [7, 0, 25],
        [5, 1, 255],
        [22, 88, 16],
        [13, 4, 131],
    ]
    mcp = matrix_copy(m)
    mmul = matrix_mul(m, m2)
    assert(len(mmul) == 5)
    assert(len(mmul[5 - 1]) == 3)
    for i in range(0, 5):
        for j in range(0, 3):
            v = 0
            for k in range(0, 4):
                v = add(v, mul(m[i][k], m2[k][j]))
            assert(mmul[i][j] == v)

    # test identity matrix
    mid = matrix_identity(5, 6)
    assert(mid == [
        [1, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0],
        [0, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, 1, 0],
    ])

    # test matrix flip
    assert(matrix_transpose(matrix_identity(5, 5)) == matrix_identity(5, 5))
    assert(matrix_transpose(matrix_identity(5, 10)) == matrix_identity(10, 5))
    mf = matrix_transpose(m)
    assert(mf != m)
    assert(mf == [
        [1, 5, 9, 13, 17],
        [2, 6, 10, 14, 18],
        [3, 7, 11, 15, 19],
        [4, 8, 12, 16, 20],
    ])
    assert(matrix_transpose(mf) == m)
    assert(matrix_transpose([
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
    ]) == [
        [1, 4, 7],
        [2, 5, 8],
        [3, 6, 9]
    ])
    mvf = matrix_transpose(generate_vandermonde(20, 26))
    assert(len(mvf) == 26)
    assert(len(mvf[0]) == 20)
    assert(len(mvf[25]) == 20)

    # test matrix topdown
    mcp = matrix_copy(m)
    mtd = matrix_topdown(mcp)
    assert(mcp == m)
    assert(mtd != mcp)
    assert(mtd == [
        [17, 18, 19, 20],
        [13, 14, 15, 16],
        [9, 10, 11, 12],
        [5, 6, 7, 8],
        [1, 2, 3, 4],
    ])
    assert(matrix_topdown(mtd) == m)

    # test matrix add
    assert(matrix_add([[1]], [[3]]) == [[add(1, 3)]])
    assert(matrix_add([
        [1, 2],
        [3, 4]
    ], [
        [5, 6],
        [7, 8]
    ]) == [
        [add(1, 5), add(2, 6)],
        [add(3, 7), add(4, 8)]
    ])

    # test matrix subtract
    assert(matrix_subtract([[1]], [[3]]) == [[subtract(1, 3)]])
    assert(matrix_subtract([
        [1, 2],
        [3, 4]
    ], [
        [5, 6],
        [7, 8]
    ]) == [
        [subtract(1, 5), subtract(2, 6)],
        [subtract(3, 7), subtract(4, 8)]
    ])

def test_matrix_invert():
    # a normal case
    m = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16],
    ]
    mi = matrix_invert(matrix_copy(m))
    assert(mi == False)

    # a vandermonde test case
    m = [
        [1, 1, 1, 1, 1],
        [1, 2, 3, 4, 5],
        [gpow(1, 2), gpow(2, 2), gpow(3, 2), gpow(4, 2), gpow(5, 2)],
        [gpow(1, 3), gpow(2, 3), gpow(3, 3), gpow(4, 3), gpow(5, 3)],
        [gpow(1, 4), gpow(2, 4), gpow(3, 4), gpow(4, 4), gpow(5, 4)],
    ]
    mi = matrix_invert(matrix_copy(m))
    assert(mi)
    mim = matrix_mul(mi, m)
    assert(mim == matrix_identity(5, 5))
    mmi = matrix_mul(m, mi)
    assert(mmi == matrix_identity(5, 5))

    # a rows < cols case
    morg = [
        [1, 1, 1, 1, 1, 99, 98, 97],
        [1, 2, 3, 4, 5, 99, 98, 97],
        [gpow(1, 2), gpow(2, 2), gpow(3, 2), gpow(4, 2), gpow(5, 2), 99, 98, 97],
        [gpow(1, 3), gpow(2, 3), gpow(3, 3), gpow(4, 3), gpow(5, 3), 99, 98, 97],
        [gpow(1, 4), gpow(2, 4), gpow(3, 4), gpow(4, 4), gpow(5, 4), 99, 98, 97],
    ]
    m = matrix_copy(morg)
    mi = matrix_invert(m)
    for i in range(0, len(morg)):
        for j in range(0, len(morg)):
            if (i == j):
                assert(m[i][j] == 1)
            else:
                assert(m[i][j] == 0)
    assert(mi)
    mim = matrix_mul(mi, morg)
    assert(mim == m)


def test_proceed_combo():
    combo = [0, 1, 2, 3, 4]
    idx = len(combo) - 1
    size = 10
    proceed_combo(combo, idx, size)
    assert(combo == [0, 1, 2, 3, 5])

    combo = [0, 1, 2, 5, 9]
    proceed_combo(combo, idx, size)
    assert(combo == [0, 1, 2, 6, 7])

    combo = [0, 1, 2, 6, 9]
    proceed_combo(combo, idx, size)
    assert(combo == [0, 1, 2, 7, 8])

    combo = [0, 2, 7, 8, 9]
    proceed_combo(combo, idx, size)
    assert(combo == [0, 3, 4, 5, 6])

    combo = [2, 6, 7, 8, 9]
    proceed_combo(combo, idx, size)
    assert(combo == [3, 4, 5, 6, 7])

    combo = [4, 6, 7, 8, 9]
    proceed_combo(combo, idx, size)
    assert(combo == [5, 6, 7, 8, 9])

    combo = [0, 1, 2, 3, 4]
    count = 1
    while(proceed_combo(combo, idx, size)):
        count += 1
    assert(count == (10 * 9 * 8 * 7 * 6) / (5 * 4 * 3 * 2 * 1))    # combination count C(10, 5)

def test_generate_vandermonde():
    assert(generate_vandermonde(5, 5) == [
        [1, 1, 1, 1, 1],
        [1, 2, 3, 4, 5],
        [gpow(1, 2), gpow(2, 2), gpow(3, 2), gpow(4, 2), gpow(5, 2)],
        [gpow(1, 3), gpow(2, 3), gpow(3, 3), gpow(4, 3), gpow(5, 3)],
        [gpow(1, 4), gpow(2, 4), gpow(3, 4), gpow(4, 4), gpow(5, 4)],
    ])

    assert(generate_vandermonde(10, 5) == [
        [1, 1, 1, 1, 1],
        [1, 2, 3, 4, 5],
        [gpow(1, 2), gpow(2, 2), gpow(3, 2), gpow(4, 2), gpow(5, 2)],
        [gpow(1, 3), gpow(2, 3), gpow(3, 3), gpow(4, 3), gpow(5, 3)],
        [gpow(1, 4), gpow(2, 4), gpow(3, 4), gpow(4, 4), gpow(5, 4)],
        
        [gpow(1, 5), gpow(2, 5), gpow(3, 5), gpow(4, 5), gpow(5, 5)],
        [gpow(1, 6), gpow(2, 6), gpow(3, 6), gpow(4, 6), gpow(5, 6)],
        [gpow(1, 7), gpow(2, 7), gpow(3, 7), gpow(4, 7), gpow(5, 7)],
        [gpow(1, 8), gpow(2, 8), gpow(3, 8), gpow(4, 8), gpow(5, 8)],
        [gpow(1, 9), gpow(2, 9), gpow(3, 9), gpow(4, 9), gpow(5, 9)],
    ])

    assert(generate_vandermonde(3, 5) == [
        [1, 1, 1, 1, 1],
        [1, 2, 3, 4, 5],
        [gpow(1, 2), gpow(2, 2), gpow(3, 2), gpow(4, 2), gpow(5, 2)],
    ])

def test_generate_cauchy():
    dim = [(1, 1), (5, 5), (10, 15), (4, 80), (66, 31), (12, 12), (5, 1)]
    for d in dim:
        m = generate_cauchy(d[0], d[1])
        for  i in range(0, len(m)):
            for j in range(0, len(m[0])):
                assert(m[i][j] == div(1, add(i, d[0] + j)))
                if (i == 0):
                    assert(m[i][j] == div(1, d[0] + j))
                if (j == 0):
                    assert(m[i][j] == div(1, add(i, d[0])))

def test_utils():
    # For sorted_array_contains_array
    assert(sorted_array_contains_array([1,2,3,5], [2,3,5]))
    assert(sorted_array_contains_array([1,2,3,5], [1,2,3,5]))
    assert(sorted_array_contains_array([1,2,3,5], [1,2,3]))
    assert(sorted_array_contains_array([1,2,3,5], [2,3]))
    assert(sorted_array_contains_array([1,2,3,5], [3]))
    assert(not sorted_array_contains_array([1,2,3,5], [2,4,5]))
    assert(not sorted_array_contains_array([1,2,3,5], [2,4]))
    assert(not sorted_array_contains_array([1,2,3,5], [0]))
    assert(not sorted_array_contains_array([1,2,3,5], [1,6]))
    assert(not sorted_array_contains_array([1,2,3,5], [6,7]))
    assert(not sorted_array_contains_array([1,2,3,5], [-1,2,3]))

def test_generate_random_matrix():
    ROW_COUNT = 200
    COL_COUNT = 400

    m = generate_random_matrix(ROW_COUNT, COL_COUNT)
    col_size = len(m[0])
    for r in m:
        assert(len(r) == col_size)
        for v in r:
            assert(v >= 0)
            assert(v < (1 << WORD_SIZE))

def test_submatrix():
    ROW_COUNT = 20
    COL_COUNT = 40
    CASE_COUNT = 100

    for caseCount in range(0, CASE_COUNT):
        m = generate_cauchy(ROW_COUNT, COL_COUNT)
        rows = random.sample(range(0, ROW_COUNT), random.randint(0, ROW_COUNT - 1))
        cols = random.sample(range(0, COL_COUNT), random.randint(0, COL_COUNT - 1))

        subm = submatrix(m, rows, cols)
        if (len(subm) <= 0):
            assert(len(rows) == 0)
            continue

        subm_col_size = len(subm[0])
        for r_idx in range(0, len(subm)):
            assert(len(subm[r_idx]) == subm_col_size)
            for c_idx in range(0, subm_col_size):
                assert(subm[r_idx][c_idx] == m[rows[r_idx]][cols[c_idx]])

def test_all_submatrix_invertible():
    m = generate_cauchy(3, 6)
    assert(all_submatrix_invertible(m) is True)

    m = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
        [10, 11, 12],
        [13, 14, 15]
    ]

    filter_list = []
    while True:
        filter_by_list = lambda rows, cols: (
                not ((rows, cols) in filter_list)
            )
        uninvertible = all_submatrix_invertible(m, filter_by_list)
        if uninvertible is True:
            break
        filter_list.append(uninvertible)
    
def tests():
    assert(WORD_SIZE >= 8)
    print("Start galois self-testing ...");
    test_by_text_book()
    test_gpow()
    test_mul()
    test_gpow()
    test_div()
    test_matrix_operations()
    test_matrix_invert()
    test_proceed_combo()
    test_generate_vandermonde()
    test_utils()
    test_generate_cauchy()
    test_generate_random_matrix()
    test_submatrix()
    test_all_submatrix_invertible()
    print("Done galois self-testing.");

def main():
    tests()

if __name__ == "__main__":
    main()
