##################################################################################
# MSR regenerating code by paper "Optimal Exact-Regenerating Codes for Distributed
# Storage at the MSR and MBR Points via a Product-Matrix Construction". It applies
# to n >= 2*k - 1 code, i.e. the parity count must be no smaller than data fragment
# count - 1.
#
# Compared to "Explicit Constructions of High-Rate MDS Array Codes With Optimal
# Repair Bandwidth", which requires each node to hold too many rows if the code has
# many fragments. This code schema allows long code such as (18, 9). It recovers
# at MSR the optimal point, which makes it a very useful regenerating code schema.
#
# The disadvantage is, when doing MDS recovery, there is extra computational
# overhead such as inverting more matrixes than plain RS code.
##################################################################################

import os
import random
import time
import galois_matrix as galois


class Context(object):
	
	def __init__(self, n, k):
		self.n = n    # how many fragments/nodes we have
		self.k = k    # how many data fragments/nodes we have
		self.alpha = k - 1    # how many symbols each node hold
		self.d = 2 * self.alpha    # how many nodes we need for regeneration

		self.phi = None    # matrix Φ
		self.psi = None    # matrix Ψ
		self.lamda = None    # matrix Λ

		self.S1 = None    # matrix S1 in the message matrix
		self.S2 = None    # matrix S2 in the message matrix
		self.M = None    # message matrix
		self.U = None    # matrix U to obtain systematic code

		self.nodes = None    # simulate each node holding data

		self.B = self.k * self.alpha    # user data size
		self.user_data = []    # original user data


def find_coding_matrix(ctx):
	xi = list(range(2, 2 + ctx.n))

	#
	# Generate coding matrix
	#

	phi = []
	for ri in range(0, ctx.n):
		row = []
		for ci in range(0, ctx.alpha):
			row.append(galois.gpow(xi[ri], ci))
		phi.append(row)
	print("Generated coding matrix component PHI:", galois.matrix_sprint(phi))

	lamda = []
	for ri in range (0, ctx.n):
		row = []
		for ci in range(0, ctx.n):
			if ci != ri:
				row.append(0)
			else:
				row.append(galois.gpow(xi[ri], ctx.alpha))
		lamda.append(row)
	print("Generated coding matrix component LAMBDA:", galois.matrix_sprint(lamda))

	lamda_mul_phi = galois.matrix_mul(lamda, phi)
	psi = galois.matrix_copy(phi)
	for ri in range(0, ctx.n):
		for ci in range(0, ctx.alpha):
			psi[ri].append(lamda_mul_phi[ri][ci])
	print("Generated coding matrix PSI:", galois.matrix_sprint(psi))

	#
	# Validations
	#

	assert(len(phi) == ctx.n)
	for ri in range(0, len(phi)):
		assert(len(phi[ri]) == ctx.alpha)

	assert(len(lamda) == ctx.n)
	for ri in range(0, len(lamda)):
		assert(len(lamda[ri]) == ctx.n)

	assert(len(psi) == ctx.n)
	for ri in range(0, len(psi)):
		assert(len(psi[ri]) == ctx.d)
	print("Validated coding matrix components PHI, PSI, LAMBDA have correct row counts and column counts.")

	for ri in range(0, ctx.n):
		for ci in range(0, ctx.d):
			assert(psi[ri][ci] == galois.gpow(xi[ri], ci))

	rows=list(range(0, 2))
	while True:
		assert(lamda[rows[0]][rows[0]] != lamda[rows[1]][rows[1]])
		if not galois.proceed_combo(rows, len(rows) - 1, ctx.n):
			break
	print("Validated coding matrix component LAMBDA has distinct elements.")

	for count in range(0, 1000):
		rows = random.sample(list(range(0, ctx.n)), ctx.alpha)
		assert(galois.matrix_invert(galois.submatrix(phi, rows, list(range(0, ctx.alpha)))))
	print("Validated any a rows of coding matrix component PHI are linear independent.")

	rows = list(range(0, ctx.d))
	while True:
		assert(galois.matrix_invert(galois.submatrix(psi, rows, list(range(0, ctx.d)))))
		if not galois.proceed_combo(rows, len(rows) - 1, ctx.n):
			break
	print("Validated any d rows of coding matrix component PSI are linear independent.")

	#
	# Update the context
	#

	ctx.phi = phi
	ctx.lamda = lamda
	ctx.psi = psi

	print("")


def input_user_data(ctx):
	for i in range(0, ctx.B):
		ctx.user_data.append(random.randint(0, 1 << galois.WORD_SIZE - 1))
	print("Generated user data, k*a=%s symbos (bytes):" % ctx.B)

	for ri in range(0, ctx.k):
		for ci in range(0, ctx.alpha):
			print("%d, " % ctx.user_data[ri * ctx.alpha + ci], end="")
		print("")
	print("")


def _MDS_decode(ctx, knodes, knodes_data):
	assert(len(knodes) == ctx.k)
	assert(len(knodes_data) == ctx.k)
	assert(len(knodes_data[0]) == ctx.alpha)

	#
	# Following paper (30) to build the post-multiplied matrix.
	# Complexity: matrix(k * a) * matrix(a * k)
	#

	phi_dc = galois.submatrix(ctx.phi, knodes, list(range(0, ctx.alpha)))
	lamda_dc = []
	for ri in range(0, ctx.k):
		row = []
		for ci in range(0, ctx.k):
			if ci != ri:
				row.append(0)
			else:
				row.append(ctx.lamda[knodes[ri]][knodes[ri]])
		lamda_dc.append(row)

	P_add_lamda_Q = galois.matrix_mul(knodes_data, galois.matrix_transpose(phi_dc))

	#
	# Following paper (33) - (35) to solve P, Q
	# Complexity: k * k
	#

	P = []
	Q = []
	for ri in range(0, ctx.k):
		p_row = []
		q_row = []
		for ci in range(0, ctx.k):
			if ri == ci:
				p_row.append(0)
				q_row.append(0)
			else:
				q = galois.div(
						galois.subtract(P_add_lamda_Q[ri][ci], P_add_lamda_Q[ci][ri]),
						galois.subtract(lamda_dc[ri][ri], lamda_dc[ci][ci]))
				p = galois.subtract(
							P_add_lamda_Q[ri][ci],
							galois.mul(lamda_dc[ri][ri], q))
				assert(p == galois.subtract(
								P_add_lamda_Q[ci][ri],
								galois.mul(lamda_dc[ci][ci], q)))
				p_row.append(p)
				q_row.append(q)
		P.append(p_row)
		Q.append(q_row)

	for ri in range(0, ctx.k):
		for ci in range(0, ctx.k):
			assert(P[ri][ci] == P[ci][ri])
			assert(Q[ri][ci] == Q[ci][ri])

	#
	# Following paper (37) - (39) to recover S1 from P
	# Complexity: a * (invert(matrix(a * a)) + matrix(1 * a) * matrix(a * a) * 2)
	#               + invert(matrix(a * a) + matrix(a * a) * matrix(a * a) * 2
	#

	phi_S1 = []
	phi_S2 = []
	for ri in range(0, ctx.alpha):
		phi_dc_exclude_ri = galois.submatrix(
			phi_dc,
			list(range(0, ri)) + list(range(ri + 1, ctx.k)),
			list(range(0, ctx.alpha)))
		phi_dc_exclude_ri_transpose_invert = galois.matrix_invert(
			galois.matrix_transpose(phi_dc_exclude_ri))
		assert(phi_dc_exclude_ri_transpose_invert is not False)
		
		P_ri_exclude_diagonal = [P[ri][0:ri] + P[ri][(ri + 1):ctx.k]]
		assert(len(P_ri_exclude_diagonal[0]) == ctx.alpha)
		phi_dc_S1_ri = galois.matrix_mul(
			P_ri_exclude_diagonal, phi_dc_exclude_ri_transpose_invert)
		assert(len(phi_dc_S1_ri) == 1)
		assert(len(phi_dc_S1_ri[0]) == ctx.alpha)
		phi_S1.append(phi_dc_S1_ri[0])

		Q_ri_exclude_diagonal = [Q[ri][0:ri] + Q[ri][(ri + 1):ctx.k]]
		assert(len(Q_ri_exclude_diagonal[0]) == ctx.alpha)
		phi_dc_S2_ri = galois.matrix_mul(
			Q_ri_exclude_diagonal, phi_dc_exclude_ri_transpose_invert)
		assert(len(phi_dc_S2_ri) == 1)
		assert(len(phi_dc_S2_ri[0]) == ctx.alpha)
		phi_S2.append(phi_dc_S2_ri[0])
	
	phi_dc_exclude_ralpha = galois.submatrix(
		phi_dc,
		list(range(0, ctx.alpha)),
		list(range(0, ctx.alpha)))
	phi_dc_exclude_ralpha_invert = galois.matrix_invert(
		phi_dc_exclude_ralpha)
	assert(phi_dc_exclude_ralpha_invert is not False)
	
	S1 = galois.matrix_mul(phi_dc_exclude_ralpha_invert, phi_S1)
	S2 = galois.matrix_mul(phi_dc_exclude_ralpha_invert, phi_S2)

	return (S1, S2)


def compose_M_from_S1_S2(ctx, S1, S2):
	assert(len(S1) == ctx.alpha)
	assert(len(S1[0]) == ctx.alpha)
	assert(len(S2) == ctx.alpha)
	assert(len(S2[0]) == ctx.alpha)

	M = []
	for ri in range(0, ctx.d):
		row = []
		for ci in range(0, ctx.alpha):
			if ri < ctx.alpha:
				row.append(S1[ri][ci])
			else:
				row.append(S2[ri - ctx.alpha][ci])
		M.append(row)

	return M


def encode(ctx):

	#
	# Following paper (46), decode message matrix M from U, So that,
	# after encode, the first k nodes hold original user data
	#

	U = []
	for ri in range(0, ctx.k):
		row = []
		for ci in range(0, ctx.alpha):
			row.append(ctx.user_data[ri * ctx.alpha + ci])
		U.append(row)
	ctx.U = U

	S1_S2 = _MDS_decode(ctx, list(range(0, ctx.k)), U)
	ctx.S1 = S1_S2[0]
	ctx.S2 = S1_S2[1]
	ctx.M = compose_M_from_S1_S2(ctx, ctx.S1, ctx.S2)
	
	print("Solved message matrix M from user data:", galois.matrix_sprint(ctx.M))

	#
	# Calculate the data that each node holds
	#

	ctx.nodes = galois.matrix_mul(ctx.psi, ctx.M)

	assert(len(ctx.nodes) == ctx.n)
	for ri in range(0, ctx.n):
		assert(len(ctx.nodes[ri]) == ctx.alpha)
		if ri < ctx.k:
			for ci in range(0, ctx.alpha):
				assert(ctx.nodes[ri][ci] == ctx.U[ri][ci])

	print("Encoded user input and replicated to each node holds:",
		  galois.matrix_sprint(ctx.nodes))
	print("")


def mds_recovery(ctx, knodes):
	print("MDS Recovering all user data from survival nodes:", knodes)
	
	knodes_data = galois.submatrix(ctx.nodes, knodes, list(range(0, ctx.alpha)))
	S1_S2 = _MDS_decode(ctx, knodes, knodes_data)
	print("Decoded message matrix component S1 and S2")

	S1 = S1_S2[0]
	S2 = S1_S2[1]
	recovered_M = compose_M_from_S1_S2(ctx, S1, S2)
	print("Recovered message matrix M")

	for ri in range(0, ctx.d):
		for ci in range(0, ctx.alpha):
			assert(recovered_M[ri][ci] == ctx.M[ri][ci])
	print("Verification passed: recovered message matrix M is the same with the original")

	print("Bandwidth consumption: k nodes * a symbols = %s, transmitted / user data = %.2f" % (
		  ctx.k * ctx.alpha,
		  ctx.k * ctx.alpha / len(ctx.user_data)))
	print("")


def regenerating_recovery(ctx, dead_node):
	print("MSR regenerating to recover dead node %s" % dead_node)

	all_nodes = list(range(0, ctx.n))
	survival_nodes = all_nodes[0:dead_node] + all_nodes[(dead_node + 1):ctx.n]
	d_nodes = random.sample(survival_nodes, ctx.d)
	print("Selected d=%s helper nodes to for data recovery:" % ctx.d, d_nodes)

	#
	# Each of the d live nodes compute the symbol to be passed to replacement node
	# Complexity: matrix(1 * a) * matrix(a * 1), at each node
	#

	psi_repair_M_phi_dead = []
	for ni in d_nodes:
		node_data = [ctx.nodes[ni]]
		phi_dead_node_tranpose = galois.matrix_transpose([ctx.phi[dead_node]])
		psi_repair_M_phi_dead.append([
			galois.matrix_mul(
				node_data,
				phi_dead_node_tranpose)[0][0]])
	print("Collect 1 symbol from each of d helper nodes to replacement node")

	#
	# On the replacement node, we try to obtain the M*phi_dead
	# Complexity: invert(matrix(d * d)) + matrix(d * d) * matrix(d * 1)
	#

	psi_repair = []
	for ni in d_nodes:
		psi_repair.append(ctx.psi[ni])
	psi_repair_invert = galois.matrix_invert(
		galois.matrix_copy(psi_repair))

	M_phi_dead = galois.matrix_mul(
		psi_repair_invert, psi_repair_M_phi_dead)

	#
	# Recover the dead node data. Following paper (27)
	# Complexity: Λ * matrix(a * 1) + matrix(a * 1) + matrix(a * 1)
	#

	S1_phi_dead = M_phi_dead[0:ctx.alpha]
	assert(len(S1_phi_dead) == ctx.alpha and len(S1_phi_dead[0]) == 1)
	S2_phi_dead = M_phi_dead[ctx.alpha:ctx.d]
	assert(len(S2_phi_dead) == ctx.alpha and len(S2_phi_dead[0]) == 1)

	dead_node_data = galois.matrix_add(
		galois.matrix_transpose(S1_phi_dead),
		galois.matrix_mul(
			[[ctx.lamda[dead_node][dead_node]]],
			galois.matrix_transpose(S2_phi_dead)))[0]

	print("Recovered the lost data of dead node on the replacement node")

	#
	# Verify the recovered data correctness
	#

	for ci in range(0, ctx.alpha):
		assert(dead_node_data[ci] == ctx.nodes[dead_node][ci])

	print("Verification passed: recovered data is the same with original")

	#
	# Print the bandwidth consumption info and comparison with MDS recovery
	#

	print("Bandwidth consumption: d nodes * 1 symbols = %s, "
		  "transmitted / user data = %.2f, "
		  "transmitted / MDS transimitted = %.2f" % (
		  ctx.d * 1,
		  ctx.d * 1 / len(ctx.user_data),
		  ctx.d * 1 / (ctx.k * ctx.alpha)))
	print("")


def main():
	ctx = Context(18, 9)
	print("Starting MSR regenerating code n=%s, k=%s. Drived a=k-1=%s d=2*a=%s" % (
		ctx.n, ctx.k, ctx.alpha, ctx.d))
	print("")

	find_coding_matrix(ctx)
	input_user_data(ctx)
	encode(ctx)

	mds_recovery(ctx, list(range(0, ctx.k)))
	mds_recovery(ctx, list(range(ctx.n - ctx.k, ctx.n)))
	for count in range(0, 2):
		knodes = random.sample(range(0, ctx.n), ctx.k)
		mds_recovery(ctx, knodes)

	regenerating_recovery(ctx, 2)
	regenerating_recovery(ctx, ctx.n - 2)
	for count in range(0, 2):
		dead_node = random.randint(0, ctx.n - 1)
		regenerating_recovery(ctx, dead_node)

	print("In summary, this MSR (18, 9) regenerating code saves recovery bandwidth "
		  "to %%%.2f of plain Reed-Solomon code." % (int(100 * ctx.d / (ctx.k * ctx.alpha))))

if __name__ == "__main__":
    main()